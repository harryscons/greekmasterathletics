document.addEventListener('DOMContentLoaded', () => {
    // --- Elements ---
    const recordForm = document.getElementById('recordForm');
    const formTitle = document.getElementById('formTitle');
    const submitBtn = document.getElementById('submitBtn');
    const cancelBtn = document.getElementById('cancelBtn');

    // Inputs
    const evtInput = document.getElementById('event');
    const genderInput = document.getElementById('gender');
    const ageGroupInput = document.getElementById('ageGroup');
    const athleteInput = document.getElementById('athlete'); // Select
    const markInput = document.getElementById('mark');
    const windInput = document.getElementById('wind');
    const dateInput = document.getElementById('date');
    let datePicker; // Flatpickr instance
    const locInput = document.getElementById('location');


    // Reports
    const reportTableBody = document.getElementById('reportTableBody');
    const emptyState = document.getElementById('emptyState');
    const filterEvent = document.getElementById('filterEvent');
    const filterGender = document.getElementById('filterGender');
    const filterAge = document.getElementById('filterAge');
    const filterYear = document.getElementById('filterYear');
    const filterAgeMismatch = document.getElementById('filterAgeMismatch');
    const statsTableBody = document.getElementById('statsTableBody');

    // Actions
    const clearAllBtn = document.getElementById('clearAll');
    const btnBackup = document.getElementById('btnBackup');
    const btnRestore = document.getElementById('btnRestore');
    const fileRestore = document.getElementById('fileRestore');

    // Navigation
    const navTabs = document.querySelectorAll('.nav-tab');
    const viewSections = document.querySelectorAll('.view-section');

    // Event Manager
    const eventForm = document.getElementById('eventForm');
    const newEventName = document.getElementById('newEventName');
    const newEventSecondary = document.getElementById('newEventSecondary');
    const newEventSpecs = document.getElementById('newEventSpecs');
    const newEventNotes = document.getElementById('newEventNotes');
    const newEventCombined = document.getElementById('newEventCombined');
    const newEventRelay = document.getElementById('newEventRelay');
    const newEventSubCount = document.getElementById('newEventSubCount');
    const subEventsContainer = document.getElementById('subEventsContainer');
    const eventListBody = document.getElementById('eventListBody');
    const eventSubmitBtn = eventForm.querySelector('button[type="submit"]');

    // Athlete Manager
    const athleteForm = document.getElementById('athleteForm');
    const newAthleteID = document.getElementById('newAthleteID');
    const newAthleteFirstName = document.getElementById('newAthleteFirstName');
    const newAthleteLastName = document.getElementById('newAthleteLastName');
    const newAthleteDOB = document.getElementById('newAthleteDOB');
    let dobPicker; // Flatpickr instance
    const newAthleteGender = document.getElementById('newAthleteGender');
    const athleteListBody = document.getElementById('athleteListBody');
    const athleteSubmitBtn = athleteForm.querySelector('button[type="submit"]');
    const btnImportAthletes = document.getElementById('btnImportAthletes');
    const athleteImportFile = document.getElementById('athleteImportFile');

    // Record Import
    const btnImportRecords = document.getElementById('btnImportRecords');
    const recordImportFile = document.getElementById('recordImportFile');

    const clearRecordsBtn = document.getElementById('clearRecords');
    const clearAthletesBtn = document.getElementById('clearAthletes');

    // Country Manager
    const countryForm = document.getElementById('countryForm');
    const newCountryName = document.getElementById('newCountryName');
    const countryListBody = document.getElementById('countryListBody');
    const countryInput = document.getElementById('country');
    const townInput = document.getElementById('town');
    const raceNameInput = document.getElementById('raceName');
    const idrInput = document.getElementById('idr');
    const notesInput = document.getElementById('notes');

    // State
    let records = [];
    let events = [];
    let athletes = [];
    let countries = [];
    let history = [];

    // Safe Loading
    try {
        records = JSON.parse(localStorage.getItem('tf_records')) || [];
    } catch (e) { console.error("Records corrupted", e); records = []; }
    try {
        events = JSON.parse(localStorage.getItem('tf_events')) || [];
    } catch (e) { console.error("Events corrupted", e); events = []; }
    try {
        athletes = JSON.parse(localStorage.getItem('tf_athletes')) || [];
    } catch (e) { console.error("Athletes corrupted", e); athletes = []; }
    try {
        countries = JSON.parse(localStorage.getItem('tf_countries')) || [];
    } catch (e) { console.error("Countries corrupted", e); countries = []; }
    try {
        history = JSON.parse(localStorage.getItem('tf_history')) || [];
    } catch (e) { console.error("History corrupted", e); history = []; }

    let editingId = null;
    let editingEventId = null;
    let editingAthleteId = null;
    let editingHistoryId = null;

    // WMA Sort State
    let wmaSortField = 'date';
    let wmaSortOrder = 'desc';

    // IAAF Data State
    let iaafData = [];
    let iaafUpdates = {};
    try {
        iaafUpdates = JSON.parse(localStorage.getItem('tf_iaaf_updates')) || {};
    } catch (e) {
        console.error("IAAF updates corrupted", e);
        iaafUpdates = {};
    }
    let isIAAFDataLoaded = false;

    // Migrate gender labels back to English
    function migrateGenderLabels() {
        let changed = false;

        // Migrate records
        records.forEach(r => {
            if (r.gender === 'Ανδρες') { r.gender = 'Male'; changed = true; }
            if (r.gender === 'Γυναίκες') { r.gender = 'Female'; changed = true; }
        });

        // Migrate athletes
        athletes.forEach(a => {
            if (a.gender === 'Ανδρες') { a.gender = 'Male'; changed = true; }
            if (a.gender === 'Γυναίκες') { a.gender = 'Female'; changed = true; }
        });

        if (changed) {
            localStorage.setItem('tf_records', JSON.stringify(records));
            localStorage.setItem('tf_athletes', JSON.stringify(athletes));
            console.log('Gender labels reverted to English');
        }
    }
    migrateGenderLabels();

    // --- Init ---
    init();

    function init() {
        setupEventListeners();

        // Default to Reports
        switchTab('reports');

        // Init Flatpickr
        try {
            if (typeof flatpickr !== 'undefined') {
                if (dateInput) {
                    datePicker = flatpickr(dateInput, {
                        dateFormat: "Y-m-d",
                        altInput: true,
                        altFormat: "d/m/Y",
                        allowInput: true,
                        defaultDate: "today"
                    });
                }
                if (newAthleteDOB) {
                    dobPicker = flatpickr(newAthleteDOB, {
                        dateFormat: "Y-m-d",
                        altInput: true,
                        altFormat: "d/m/Y",
                        allowInput: true
                    });
                }
            } else {
                console.warn('Flatpickr library not loaded.');
            }
        } catch (e) {
            console.error('Flatpickr init failed:', e);
        }

        // Migrations
        migrateAthletes();
        migrateAthleteNames();
        migrateEvents();
        migrateRecordFormat();
        migrateAgeGroupsToStartAge();
        migrateEventDescriptions();

        // Seeding
        // Seeding
        seedEvents();
        seedCountries();
        seedRecords();

        populateAgeSelects();
        populateEventDropdowns();
        populateAthleteDropdown();
        populateCountryDropdown();

        renderEventList();
        renderAthleteList();
        renderCountryList();
        renderCountryList();
        renderHistoryList(); // Ensure this exists

        // Run cleanup
        cleanupDuplicateAthletes();

        console.log("Rendered lists. Now populating year dropdown..."); // DEBUG

        // Defaults
        if (dateInput) {
            if (datePicker) {
                datePicker.setDate(new Date());
            } else if (dateInput.type === 'date') {
                dateInput.valueAsDate = new Date();
            } else {
                // Fallback for text input
                dateInput.value = new Date().toISOString().split('T')[0];
            }
        }

        try {
            populateYearDropdown();
            // Set default to current year
            if (filterYear) {
                filterYear.value = new Date().getFullYear().toString();
            }
            console.log("populateYearDropdown finished. Default set to current year."); // DEBUG
        } catch (e) {
            console.error("Error in populateYearDropdown:", e);
            alert("Error initializing Year Dropdown: " + e.message);
        }

        renderReports();
        renderReports();
        console.log("Init finished."); // DEBUG
    }

    function seedEvents() {
        const defaults = {
            "10000μ": "10,000m", "10000μ Βάδην": "10,000m Race Walk", "100μ": "100m",
            "100μ Εμπόδια": "100m Hurdles", "110μ Εμπόδια": "110m Hurdles", "1500μ": "1,500m",
            "20000μ Βάδην": "20,000m Race Walk", "2000μ ΦΕ": "2,000m Steeplechase", "200μ": "200m",
            "200μ Εμπόδια": "200m Hurdles", "3000μ": "3,000m", "3000μ Βάδην": "3,000m Race Walk",
            "3000μ ΦΕ": "3,000m Steeplechase", "300μ Εμπόδια": "300m Hurdles", "400μ": "400m",
            "400μ Εμπόδια": "400m Hurdles", "4x100": "4x100m Relay", "4x400": "4x400m Relay",
            "5000μ": "5,000m", "5000μ Βάδην": "5,000m Race Walk", "800μ": "800m",
            "80μ Εμπόδια": "80m Hurdles", "Ακόντιο": "Javelin Throw", "Βαλκανική Σκυτάλη": "Balkan Relay",
            "Βαρύ Οργανο": "Weight Throw", "Δέκαθλο": "Decathlon", "Δίσκος": "Discus Throw",
            "Επι Κοντώ": "Pole Vault", "Έπταθλο": "Heptathlon", "Ημιμαραθώνιος": "Half Marathon",
            "Μαραθώνιος": "Marathon", "Μήκος": "Long Jump", "Πένταθλο": "Pentathlon",
            "Πένταθλο Ρίψεων": "Throws Pentathlon", "Σφαίρα": "Shot Put", "Σφύρα": "Hammer Throw",
            "Τριπλούν": "Triple Jump", "Υψος": "High Jump"
        };

        let changed = false;
        Object.entries(defaults).forEach(([name, desc]) => {
            const exists = events.some(e => e.name.trim().toLowerCase() === name.trim().toLowerCase());

            if (!exists) {
                const isRelay = name.includes('4x') || name.includes('Σκυτάλη');
                const isCombined = ["Δέκαθλο", "Έπταθλο", "Πένταθλο", "Πένταθλο Ρίψεων"].includes(name);

                events.push({
                    id: Date.now() + Math.random(),
                    name: name.trim(),
                    descriptionEn: desc,
                    specs: '',
                    notes: '',
                    isCombined: isCombined,
                    isRelay: isRelay
                });
                changed = true;
            }
        });

        // Ensure properties exist
        events.forEach(ev => {
            if (ev.notes === undefined) { ev.notes = ''; changed = true; }
        });

        if (changed) {
            saveEvents();
            console.log("Seeded/Updated events.");
        }
    }

    function seedCountries() {
        if (countries.length === 0 || (countries.length > 0 && countries.includes("USA") && !countries.includes("ΗΠΑ"))) {
            // Seed if empty OR if it looks like the old English list
            countries = [
                'Ελλάδα', 'Κύπρος', 'ΗΠΑ', 'Ηνωμένο Βασίλειο', 'Γερμανία', 'Γαλλία', 'Ιταλία', 'Ισπανία',
                'Τζαμάικα', 'Κένυα', 'Αιθιοπία', 'Καναδάς', 'Αυστραλία', 'Ιαπωνία', 'Κίνα', 'Ρωσία', 'Βραζιλία'
            ].sort();
            saveCountries();
            console.log("Seeded Countries");
        }
    }

    function seedRecords() {
        if (records.length === 0) {
            console.log("Seeding Records...");
            records = [
                {
                    id: 1770471179553.6404, event: "Υψος", athlete: "Γκούζια, Ελένη", gender: "Female", ageGroup: "65", mark: "1.06", wind: "", idr: "Α", date: "1905-07-02", country: "", town: "Νιρεγκιάζα, Ουγγαρία", raceName: "Πανευρωπαϊκό Πρωτάθλημα"
                },
                {
                    id: 1770471179553.0273, event: "Υψος", athlete: "Φιλιππάκη, Σοφία", gender: "Female", ageGroup: "60", mark: "1.15", wind: "", idr: "Γ", date: "2023-09-01", country: "", town: "Σμύρνη, Τουρκία", raceName: "Βαλκανικό Πρωτάθλημα"
                },
                {
                    id: 1770471179552.843, event: "Υψος", athlete: "Μπακογιάννη, Νίκη", gender: "Female", ageGroup: "35", mark: "1.85", wind: "", idr: "Α", date: "2004-06-12", country: "", town: "Αθήνα, Μαρούσι", raceName: "Πανελλήνιο Πρωτάθλημα Α/Γ"
                }
            ];
            saveRecords();
        }
    }


    function migrateRecordFormat() {
        let changed = false;
        records.forEach(r => {
            if (r.athlete && !r.athlete.includes(',')) {
                const match = athletes.find(a => `${a.firstName} ${a.lastName}`.trim() === r.athlete);
                if (match) {
                    r.athlete = `${match.lastName}, ${match.firstName}`;
                    changed = true;
                } else {
                    const parts = r.athlete.trim().split(' ');
                    if (parts.length >= 2) {
                        const last = parts.pop();
                        const first = parts.join(' ');
                        r.athlete = `${last}, ${first}`;
                        changed = true;
                    }
                }
            }
        });
        if (changed) saveRecords();
    }

    function migrateEvents() {
        if (events.length > 0 && typeof events[0] === 'string') {
            console.log("Migrating Events to Object Schema...");
            events = events.map(name => ({
                id: Date.now() + Math.random(),
                name: name,
                specs: '',
                notes: '',
                isCombined: false,
                isRelay: false
            }));
            saveEvents();
        }
    }

    function migrateEventDescriptions() {
        const defaults = {
            "10000μ": "10,000m", "10000μ Βάδην": "10,000m Race Walk", "100μ": "100m",
            "100μ Εμπόδια": "100m Hurdles", "110μ Εμπόδια": "110m Hurdles", "1500μ": "1,500m",
            "20000μ Βάδην": "20,000m Race Walk", "2000μ ΦΕ": "2,000m Steeplechase", "200μ": "200m",
            "200μ Εμπόδια": "200m Hurdles", "3000μ": "3,000m", "3000μ Βάδην": "3,000m Race Walk",
            "3000μ ΦΕ": "3,000m Steeplechase", "300μ Εμπόδια": "300m Hurdles", "400μ": "400m",
            "400μ Εμπόδια": "400m Hurdles", "4x100": "4x100m Relay", "4x400": "4x400m Relay",
            "5000μ": "5,000m", "5000μ Βάδην": "5,000m Race Walk", "800μ": "800m",
            "80μ Εμπόδια": "80m Hurdles", "Ακόντιο": "Javelin Throw", "Βαλκανική Σκυτάλη": "Balkan Relay",
            "Βαρύ Οργανο": "Weight Throw", "Δέκαθλο": "Decathlon", "Δίσκος": "Discus Throw",
            "Επι Κοντώ": "Pole Vault", "Έπταθλο": "Heptathlon", "Ημιμαραθώνιος": "Half Marathon",
            "Μαραθώνιος": "Marathon", "Μήκος": "Long Jump", "Πένταθλο": "Pentathlon",
            "Πένταθλο Ρίψεων": "Throws Pentathlon", "Σφαίρα": "Shot Put", "Σφύρα": "Hammer Throw",
            "Τριπλούν": "Triple Jump", "Υψος": "High Jump"
        };
        let changed = false;
        events.forEach(ev => {
            if (ev.descriptionEn === undefined) {
                // Try to match default
                const key = Object.keys(defaults).find(k => k.toLowerCase() === ev.name.toLowerCase());
                ev.descriptionEn = key ? defaults[key] : '';
                changed = true;
            }
        });
        if (changed) saveEvents();
    }

    function migrateAthletes() {
        let changed = false;
        records.forEach(r => {
            const name = r.athlete;
            if (!name) return;

            const isComma = name.includes(',');

            // normalize record name
            let rFirst = '', rLast = '';
            if (isComma) {
                const parts = name.split(',');
                rLast = parts[0].trim();
                rFirst = parts[1] ? parts[1].trim() : '';
            } else {
                const parts = name.trim().split(' ');
                if (parts.length > 1) {
                    rFirst = parts[0];
                    rLast = parts.slice(1).join(' ');
                } else {
                    rLast = name.trim();
                }
            }

            const rFirstLower = rFirst.toLowerCase();
            const rLastLower = rLast.toLowerCase();

            const exists = athletes.some(a => {
                const aFirst = a.firstName.toLowerCase();
                const aLast = a.lastName.toLowerCase();

                // Check exact match
                if (aFirst === rFirstLower && aLast === rLastLower) return true;

                // Check swapped match (Record: "Last First" vs Athlete: "First Last")
                // e.g. Record "Bolt Usain" vs Athlete "Usain Bolt"
                // In my parsing logic above, if record was "Bolt Usain" (no comma), rFirst="Bolt", rLast="Usain"
                // Athlete is First="Usain", Last="Bolt"
                if (aFirst === rLastLower && aLast === rFirstLower) return true;

                // Check concatenated
                const flName = `${a.firstName} ${a.lastName}`.toLowerCase();
                const lfName = `${a.lastName}, ${a.firstName}`.toLowerCase();
                const recNameLower = name.toLowerCase();

                return flName === recNameLower || lfName === recNameLower;
            });

            if (!exists) {
                // Only add if we rely purely on the record's format
                let first = rFirst || 'Unknown';
                let last = rLast || name;

                athletes.push({
                    id: Date.now() + Math.random(),
                    idNumber: '',
                    firstName: first,
                    lastName: last,
                    dob: '',
                    gender: r.gender || ''
                });
                changed = true;
            }
        });

        if (changed) saveAthletes();
    }

    function migrateAthleteNames() {
        let changed = false;
        athletes.forEach(a => {
            if (a.name) {
                const parts = a.name.trim().split(' ');
                a.firstName = parts.shift() || 'Unknown';
                a.lastName = parts.join(' ') || '';
                delete a.name;
                changed = true;
            }
        });
        if (changed) saveAthletes();
    }

    // --- Logic ---
    function populateAgeSelects() {
        const groups = [];
        for (let i = 35; i < 100; i += 5) {
            groups.push(i.toString());
        }
        groups.push('100+');

        if (ageGroupInput) {
            ageGroupInput.innerHTML = '';
            groups.forEach(g => {
                const opt = document.createElement('option');
                opt.value = g;
                opt.textContent = g;
                ageGroupInput.appendChild(opt);
            });
        }

        if (filterAge) {
            filterAge.innerHTML = '<option value="all">All Age Groups</option>';
            groups.forEach(g => {
                const opt = document.createElement('option');
                opt.value = g;
                opt.textContent = g;
                filterAge.appendChild(opt);
            });
        }
    }

    function populateYearDropdown() {
        if (!filterYear) {
            console.error("filterYear element not found!");
            return;
        }

        // Extract unique years from records
        const years = new Set();
        const currentYear = new Date().getFullYear();
        years.add(currentYear); // Always include current year

        console.log("Records for years:", records.length);

        if (records.length === 0) {
            console.warn("No records found.");
        }

        records.forEach(r => {
            if (r.date) {
                // Handle different date formats just in case
                const d = new Date(r.date);
                if (!isNaN(d.getTime())) {
                    years.add(d.getFullYear());
                } else {
                    console.warn("Invalid date found:", r.date);
                }
            }
        });

        const sortedYears = Array.from(years).sort((a, b) => b - a); // Descending
        console.log("Years found:", sortedYears);

        filterYear.innerHTML = '<option value="all" style="color:black;">All Years</option>';

        sortedYears.forEach(y => {
            const opt = document.createElement('option');
            opt.value = y.toString();
            opt.textContent = y.toString();
            opt.style.color = 'black'; // Force visibility
            filterYear.appendChild(opt);
        });
    }

    function populateEventDropdowns() {
        if (evtInput) {
            evtInput.innerHTML = '<option value="" disabled selected>Select Event</option>';
            events.forEach(ev => {
                const opt = document.createElement('option');
                opt.value = ev.name;
                opt.textContent = ev.name;
                evtInput.appendChild(opt);
            });
        }

        if (filterEvent) {
            filterEvent.innerHTML = '<option value="all">All Events</option>';
            events.forEach(ev => {
                const opt = document.createElement('option');
                opt.value = ev.name;
                opt.textContent = ev.name;
                filterEvent.appendChild(opt);
            });
        }
    }

    function populateAthleteDropdown() {
        athletes.sort((a, b) => {
            const lastA = a.lastName || '';
            const lastB = b.lastName || '';
            const firstA = a.firstName || '';
            const firstB = b.firstName || '';

            if (lastA === lastB) return firstA.localeCompare(firstB);
            return lastA.localeCompare(lastB);
        });

        if (athleteInput) {
            athleteInput.innerHTML = '<option value="" disabled selected>Select Athlete</option>';
            athletes.forEach(a => {
                const opt = document.createElement('option');
                const idText = a.idNumber ? ` (#${a.idNumber})` : '';
                opt.textContent = `${a.lastName}${a.lastName ? ', ' : ''}${a.firstName}${idText}`;
                opt.value = `${a.lastName}, ${a.firstName}`;
                opt.dataset.id = a.id;
                athleteInput.appendChild(opt);
            });
        }
    }

    function setupEventListeners() {
        navTabs.forEach(tab => {
            tab.addEventListener('click', () => switchTab(tab.dataset.tab));
        });

        document.querySelectorAll('.sub-tab').forEach(tab => {
            tab.addEventListener('click', () => switchSubTab(tab.dataset.subtab));
        });
        document.querySelectorAll('.stats-sub-tab').forEach(tab => {
            tab.addEventListener('click', () => switchStatsSubTab(tab.dataset.statSubtab));
        });

        if (recordForm) recordForm.addEventListener('submit', handleFormSubmit);
        if (cancelBtn) cancelBtn.addEventListener('click', cancelEdit);

        function updateCalculatedAgeGroup() {
            const name = athleteInput.value;
            const selectedDate = dateInput.value;
            const athlete = athletes.find(a => `${a.lastName}, ${a.firstName}` === name);

            if (athlete && athlete.dob && selectedDate) {
                const ageGroup = calculateAgeGroup(athlete.dob, selectedDate);
                if (ageGroup && ageGroupInput) {
                    ageGroupInput.value = ageGroup;
                }
            }
        }

        if (athleteInput) {
            athleteInput.addEventListener('change', () => {
                const name = athleteInput.value;
                let athlete = athletes.find(a => `${a.lastName}, ${a.firstName}` === name);

                if (athlete) {
                    if (athlete.gender && genderInput) genderInput.value = athlete.gender;
                    updateCalculatedAgeGroup();
                }
            });
        }

        if (dateInput) {
            dateInput.addEventListener('change', updateCalculatedAgeGroup);
        }

        if (evtInput) {
            evtInput.addEventListener('change', () => {
                const eventName = evtInput.value;
                handleMixedGenderVisibility(eventName);
            });
        }

        if (eventForm) eventForm.addEventListener('submit', handleEventSubmit);
        if (eventListBody) {
            eventListBody.addEventListener('click', (e) => {
                const delBtn = e.target.closest('.delete-event-btn');
                const editBtn = e.target.closest('.edit-event-btn');
                if (delBtn && !delBtn.disabled) deleteEvent(delBtn.dataset.id);
                if (editBtn) editEvent(editBtn.dataset.id);
            });
        }

        if (athleteForm) athleteForm.addEventListener('submit', handleAthleteSubmit);
        if (athleteListBody) {
            athleteListBody.addEventListener('click', (e) => {
                const delBtn = e.target.closest('.delete-athlete-btn');
                const editBtn = e.target.closest('.edit-athlete-btn');
                console.log('AthleteList Click:', e.target, 'EditBtn:', editBtn, 'DelBtn:', delBtn);

                if (delBtn && !delBtn.disabled) deleteAthlete(delBtn.dataset.id);
                if (editBtn) {
                    const idToEdit = delBtn ? delBtn.dataset.id : editBtn.dataset.id;
                    console.log('Editing ID:', idToEdit);
                    editAthlete(idToEdit);
                }
            });
        }

        if (newEventCombined) {
            newEventCombined.addEventListener('change', () => {
                if (newEventCombined.checked) {
                    newEventRelay.checked = false;
                    newEventSubCount.disabled = false;
                    newEventSubCount.focus();
                } else {
                    newEventSubCount.disabled = true;
                    newEventSubCount.value = '';
                    subEventsContainer.innerHTML = '';
                    subEventsContainer.style.display = 'none';
                }
            });
        }

        if (newEventRelay) {
            newEventRelay.addEventListener('change', () => {
                if (newEventRelay.checked) {
                    newEventCombined.checked = false;
                    newEventSubCount.disabled = true;
                    newEventSubCount.value = '';
                    subEventsContainer.innerHTML = '';
                    subEventsContainer.style.display = 'none';
                }
            });
        }

        if (newEventSubCount) {
            newEventSubCount.addEventListener('input', () => {
                const count = parseInt(newEventSubCount.value) || 0;
                subEventsContainer.innerHTML = '';

                if (count > 0) {
                    subEventsContainer.style.display = 'flex';

                    // Generate Options
                    let options = '<option value="" disabled selected>Select Event</option>';
                    // Filter out Combined and Relay events
                    const availableEvents = events.filter(e => !e.isCombined && !e.isRelay);
                    availableEvents.sort((a, b) => a.name.localeCompare(b.name));

                    availableEvents.forEach(e => {
                        options += `<option value="${e.name}">${e.name}</option>`;
                    });

                    for (let i = 1; i <= count; i++) {
                        const div = document.createElement('div');
                        div.className = 'form-group';
                        div.style.flex = '1 1 45%'; // Responsive-ish
                        div.style.minWidth = '150px';
                        div.innerHTML = `
                            <label style="font-size:0.75rem;">Event ${i}</label>
                            <select class="sub-event-input" required style="width:100%;">
                                ${options}
                            </select>
                        `;
                        subEventsContainer.appendChild(div);
                    }
                } else {
                    subEventsContainer.style.display = 'none';
                }
            });
        }

        if (filterEvent) filterEvent.addEventListener('change', renderReports);
        const sortBy = document.getElementById('sortBy');
        if (sortBy) sortBy.addEventListener('change', renderReports);

        if (filterGender) filterGender.addEventListener('change', genderFilterChange);
        if (filterAge) filterAge.addEventListener('change', renderReports);
        if (filterYear) filterYear.addEventListener('change', renderReports);
        if (filterAgeMismatch) filterAgeMismatch.addEventListener('change', renderReports);

        if (clearAllBtn) clearAllBtn.addEventListener('click', clearAllData);
        if (clearRecordsBtn) {
            clearRecordsBtn.addEventListener('click', () => {
                if (confirm('Are you sure you want to DELETE ALL RECORDS? This cannot be undone.')) {
                    records = [];
                    saveRecords();
                    renderReports();
                    renderHistoryList();
                    alert('All records deleted.');
                }
            });
        }

        if (clearAthletesBtn) {
            clearAthletesBtn.addEventListener('click', () => {
                if (confirm('Are you sure you want to DELETE ALL ATHLETES? This cannot be undone.')) {
                    athletes = [];
                    saveAthletes();
                    renderAthleteList();
                    populateAthleteDropdown();
                    alert('All athletes deleted.');
                }
            });
        }

        if (btnImportRecords) {
            console.log("Import Records Button Found");
            btnImportRecords.addEventListener('click', () => {
                console.log("Import Button Clicked");
                if (recordImportFile) recordImportFile.click();
                else alert("File input not found!");
            });
        } else {
            console.error("Import Records Button NOT Found");
        }
        if (btnImportAthletes) btnImportAthletes.addEventListener('click', () => athleteImportFile.click());
        if (athleteImportFile) athleteImportFile.addEventListener('change', handleAthleteImport);

        if (recordImportFile) {
            recordImportFile.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) importRecordsFromFile(file);
            });
        }

        if (athleteListBody) {
            athleteListBody.addEventListener('click', (e) => {
                const editBtn = e.target.closest('.edit-athlete-btn');
                const delBtn = e.target.closest('.delete-athlete-btn');
                if (editBtn) editAthlete(editBtn.dataset.id);
                if (delBtn) deleteAthlete(delBtn.dataset.id);
            });
        }

        const btnExcel = document.getElementById('exportExcel');
        if (btnExcel) btnExcel.addEventListener('click', exportToExcel);

        const btnHTML = document.getElementById('exportHTML');
        if (btnHTML) btnHTML.addEventListener('click', exportToHTML);

        const btnPDF = document.getElementById('exportPDF');
        if (btnPDF) btnPDF.addEventListener('click', exportToPDF);

        if (btnBackup) btnBackup.addEventListener('click', exportDatabase);
        if (btnRestore) btnRestore.addEventListener('click', importDatabase);

        if (reportTableBody) {
            reportTableBody.addEventListener('click', (e) => {
                const expandBtn = e.target.closest('.expand-btn');
                const editBtn = e.target.closest('.edit-btn');
                const delBtn = e.target.closest('.delete-btn');

                if (expandBtn) {
                    const id = expandBtn.dataset.id;
                    const detailRow = document.getElementById(`detail-${id}`);
                    if (detailRow) {
                        detailRow.classList.toggle('hidden');
                        expandBtn.textContent = detailRow.classList.contains('hidden') ? '+' : '−';
                    }
                }
                if (editBtn) editRecord(Number(editBtn.dataset.id));
                if (delBtn) deleteRecord(Number(delBtn.dataset.id));
            });
        }

        if (countryForm) countryForm.addEventListener('submit', handleCountrySubmit);
        if (countryListBody) {
            countryListBody.addEventListener('click', (e) => {
                const delBtn = e.target.closest('.delete-country-btn');
                if (delBtn) deleteCountry(delBtn.dataset.country);
            });
        }

        const historyListBody = document.getElementById('historyListBody');
        if (historyListBody) {
            historyListBody.addEventListener('click', (e) => {
                const expandBtn = e.target.closest('.expand-btn');
                const delBtn = e.target.closest('.delete-history-btn');
                const editBtn = e.target.closest('.edit-history-btn');

                if (expandBtn) {
                    const id = expandBtn.dataset.id;
                    const detailRow = document.getElementById(`detail-hist-${id}`);
                    if (detailRow) {
                        detailRow.classList.toggle('hidden');
                        expandBtn.textContent = detailRow.classList.contains('hidden') ? '+' : '−';
                    }
                }
                if (delBtn) deleteHistory(Number(delBtn.dataset.id));
                if (editBtn) editHistory(Number(editBtn.dataset.id));
            });
        }
    }

    function switchTab(tabId) {
        // Hide all views by removing active class
        document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active-view'));

        // Show target view
        const target = document.getElementById('view-' + tabId);
        if (target) {
            target.classList.add('active-view');
        }

        // Update nav buttons
        document.querySelectorAll('.nav-tab').forEach(el => el.classList.remove('active'));
        const btn = document.querySelector(`.nav-tab[data-tab="${tabId}"]`);
        if (btn) btn.classList.add('active');

        // Handling specific views
        if (tabId === 'history') renderHistoryList();
        if (tabId === 'stats') {
            const activeSub = document.querySelector('#view-stats .stats-sub-tab.active');
            if (activeSub) switchStatsSubTab(activeSub.dataset.statSubtab);
            else switchStatsSubTab('medals');
        }

        // Settings View Default
        if (tabId === 'settings') {
            const activeSub = document.querySelector('#view-settings .sub-tab.active');
            if (activeSub) {
                switchSubTab(activeSub.dataset.subtab);
            } else {
                switchSubTab('athletes');
            }
        }
    }

    function switchSubTab(subTabId) {
        // Hide all setting sections
        document.querySelectorAll('.setting-section').forEach(el => el.classList.add('hidden'));

        // Show target section
        const target = document.getElementById('setting-' + subTabId);
        if (target) {
            target.classList.remove('hidden');
        }

        // Update sub-tab buttons
        document.querySelectorAll('#view-settings .sub-tab').forEach(el => el.classList.remove('active'));
        const btn = document.querySelector(`#view-settings .sub-tab[data-subtab="${subTabId}"]`);
        if (btn) btn.classList.add('active');

        // Render lists if needed
        try {
            if (subTabId === 'athletes') renderAthleteList();
            if (subTabId === 'events') renderEventList();
            if (subTabId === 'countries') renderCountryList();
            if (subTabId === 'iaaf') {
                loadIAAFData();
            }
        } catch (e) {
            // Error rendering list for subTabId
        }
    }

    function switchStatsSubTab(subTabId) {
        document.querySelectorAll('.stats-section').forEach(el => el.classList.add('hidden'));
        const target = document.getElementById('stats-' + subTabId);
        if (target) target.classList.remove('hidden');

        document.querySelectorAll('.stats-sub-tab').forEach(el => el.classList.remove('active'));
        const btn = document.querySelector(`.stats-sub-tab[data-stat-subtab="${subTabId}"]`);
        if (btn) btn.classList.add('active');

        if (subTabId === 'medals') renderStats();
        if (subTabId === 'wma') renderWMAReport();
    }

    function renderWMAReport() {
        const tbody = document.getElementById('wmaReportBody');
        tbody.innerHTML = '';

        // Filter and Sort Records
        let sortedRecords = [...records];

        sortedRecords.sort((a, b) => {
            let valA = a[wmaSortField];
            let valB = b[wmaSortField];

            // Handle virtual fields or complex lookups
            if (wmaSortField === 'athlete') {
                valA = a.athlete || '';
                valB = b.athlete || '';
            } else if (wmaSortField === 'age') {
                // Calculate age
                const athA = athletes.find(at => at.id == a.athleteId);
                const athB = athletes.find(at => at.id == b.athleteId);
                let ageA = -1, ageB = -1;
                if (athA && athA.dob && a.date) ageA = ((new Date(a.date) - new Date(athA.dob)) / (31557600000));
                if (athB && athB.dob && b.date) ageB = ((new Date(b.date) - new Date(athB.dob)) / (31557600000));
                valA = ageA;
                valB = ageB;
            } else if (wmaSortField === 'mark') {
                // Simplified mark sort (string comparison for now, ideally parsed number)
                // Try to parse number if possible?
                // For now, string fallback or simple numeric
                const numA = parseFloat(a.mark) || 0;
                const numB = parseFloat(b.mark) || 0;
                if (numA && numB) { valA = numA; valB = numB; }
            }

            if (valA < valB) return wmaSortOrder === 'asc' ? -1 : 1;
            if (valA > valB) return wmaSortOrder === 'asc' ? 1 : -1;
            return 0;
        });

        if (sortedRecords.length === 0) {
            tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;">No records found.</td></tr>';
            return;
        }

        sortedRecords.forEach(r => {
            // Get athlete name - records store it directly in r.athlete field
            const athleteName = r.athlete || 'Unknown';
            const gender = r.gender || '-';

            // Calculate age at event - need to find athlete by name for DOB
            let ageAtEvent = '-';
            const athlete = athletes.find(a => `${a.lastName}, ${a.firstName}` === r.athlete);
            if (athlete && athlete.dob && r.date) {
                const eventDate = new Date(r.date);
                const dob = new Date(athlete.dob);
                const diffTime = eventDate - dob;
                ageAtEvent = Math.floor(diffTime / (1000 * 60 * 60 * 24 * 365.25));
            }

            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${r.event}</td>
                <td>${athleteName}</td>
                <td>${gender}</td>
                <td>${ageAtEvent}</td>
                <td>${r.mark}</td>
                <td>${r.idr || '-'}</td>
                <td>-</td> <!-- RateConv -->
                <td>-</td> <!-- AgeMark -->
                <td>-</td> <!-- Pts -->
                <td>${r.date}</td>
                <td>${r.raceName || '-'}</td>
            `;
            tbody.appendChild(row);
        });
    }

    window.sortWMAReport = function (field) {
        if (wmaSortField === field) {
            wmaSortOrder = wmaSortOrder === 'asc' ? 'desc' : 'asc';
        } else {
            wmaSortField = field;
            wmaSortOrder = 'asc'; // Default new sort to ascending
            // Exception for Date and Mark -> Default Descending usually better?
            if (field === 'date' || field === 'mark' || field === 'pts') {
                wmaSortOrder = 'desc';
            }
        }
        renderWMAReport();
    };
    function cleanupDuplicateAthletes() {
        const groups = {};

        // Group by normalized name (agnostic to First/Last order)
        athletes.forEach(a => {
            const f = (a.firstName || '').toLowerCase().trim();
            const l = (a.lastName || '').toLowerCase().trim();

            // Sort to handle "John Doe" vs "Doe John"
            const key = [f, l].sort().join('|');

            if (!groups[key]) groups[key] = [];
            groups[key].push(a);
        });

        let removedCount = 0;
        const newAthletes = [];

        Object.values(groups).forEach(group => {
            if (group.length === 1) {
                newAthletes.push(group[0]);
            } else {
                // Duplicates found
                const withDOB = group.filter(a => a.dob && a.dob.trim() !== "");
                const noDOB = group.filter(a => !a.dob || a.dob.trim() === "");

                if (withDOB.length > 0) {
                    // Keep ones with DOB
                    withDOB.forEach(a => newAthletes.push(a));
                    removedCount += noDOB.length;
                } else {
                    // None have DOB, keep first one
                    newAthletes.push(group[0]);
                    removedCount += (group.length - 1);
                }
            }
        });

        if (removedCount > 0) {
            athletes = newAthletes;
            saveAthletes();
            console.log(`Cleaned up ${removedCount} duplicate athletes.`);
            alert(`System Maintenance: Removed ${removedCount} duplicate athlete profiles.`);
        }
    }

    function calculateAgeGroup(dobStr, eventDateStr) {
        const dob = new Date(dobStr);
        const evt = new Date(eventDateStr);
        if (isNaN(dob) || isNaN(evt)) return null;

        let age = evt.getFullYear() - dob.getFullYear();
        const m = evt.getMonth() - dob.getMonth();
        if (m < 0 || (m === 0 && evt.getDate() < dob.getDate())) {
            age--;
        }

        if (age < 35) return null;
        if (age >= 100) return '100+';
        return (Math.floor(age / 5) * 5).toString();
    }

    function migrateAgeGroupsToStartAge() {
        let changed = false;
        records.forEach(r => {
            if (r.ageGroup && r.ageGroup.includes('-')) {
                r.ageGroup = r.ageGroup.split('-')[0];
                changed = true;
            }
        });
        history.forEach(h => {
            if (h.ageGroup && h.ageGroup.includes('-')) {
                h.ageGroup = h.ageGroup.split('-')[0];
                changed = true;
            }
        });
        if (changed) {
            saveRecords();
            localStorage.setItem('tf_history', JSON.stringify(history));
            console.log("Migrated Age Groups to Start Age format.");
        }
    }

    // --- Athlete CRUD ---
    function handleAthleteSubmit(e) {
        e.preventDefault();
        const first = newAthleteFirstName.value.trim();
        const last = newAthleteLastName.value.trim();
        const idNum = newAthleteID.value.trim();

        if (!first || !last) return;

        if (editingAthleteId) {
            const idx = athletes.findIndex(a => a.id == editingAthleteId);
            if (idx !== -1) {
                const oldNameLF = `${athletes[idx].lastName}, ${athletes[idx].firstName}`;

                athletes[idx].idNumber = idNum;
                athletes[idx].firstName = first;
                athletes[idx].lastName = last;
                athletes[idx].dob = newAthleteDOB.value;
                athletes[idx].gender = newAthleteGender.value;

                const newNameLF = `${last}, ${first}`;

                // Propagate Name Update
                records.forEach(r => {
                    if (r.athlete === oldNameLF) r.athlete = newNameLF;
                    else if (r.athlete === `${athletes[idx].firstName} ${athletes[idx].lastName}`) r.athlete = newNameLF;
                });
            }

            editingAthleteId = null;
            athleteSubmitBtn.innerHTML = '<span>+ Save Athlete</span>';
            athleteSubmitBtn.style.background = '';
        } else {
            const exists = athletes.some(a =>
                (a.firstName.toLowerCase() === first.toLowerCase() &&
                    a.lastName.toLowerCase() === last.toLowerCase()) ||
                (idNum && a.idNumber === idNum)
            );

            if (exists) return alert('Athlete already exists (Name or ID match)!');

            athletes.push({
                id: Date.now(),
                idNumber: idNum,
                firstName: first,
                lastName: last,
                dob: newAthleteDOB.value,
                gender: newAthleteGender.value
            });
        }

        saveAthletes();
        saveRecords();
        populateAthleteDropdown();
        renderAthleteList();
        renderReports();

        newAthleteID.value = '';
        newAthleteFirstName.value = '';
        newAthleteLastName.value = '';
        newAthleteLastName.value = '';
        if (dobPicker) dobPicker.clear();
        else newAthleteDOB.value = '';
        newAthleteGender.value = '';
        newAthleteFirstName.focus();
    }

    function editAthlete(id) {
        console.log('editAthlete called with:', id);
        const athlete = athletes.find(a => a.id == id);
        console.log('Found athlete:', athlete);
        if (!athlete) return;

        newAthleteID.value = athlete.idNumber || '';
        newAthleteFirstName.value = athlete.firstName;
        newAthleteLastName.value = athlete.lastName;

        if (dobPicker) dobPicker.setDate(athlete.dob);
        else newAthleteDOB.value = athlete.dob;

        newAthleteGender.value = athlete.gender;

        editingAthleteId = id;
        athleteSubmitBtn.innerHTML = '<span>Update Athlete</span>';
        athleteSubmitBtn.style.background = 'linear-gradient(135deg, var(--warning), #f59e0b)';

        // Scroll to form so user sees the change
        athleteForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    function deleteAthlete(id) {
        const athlete = athletes.find(a => a.id == id);
        if (!athlete) return;

        const fullNameLF = `${athlete.lastName}, ${athlete.firstName}`;
        const fullNameFL = `${athlete.firstName} ${athlete.lastName}`;

        const isUsed = records.some(r => r.athlete === fullNameLF || r.athlete === fullNameFL);
        if (isUsed) return alert(`Cannot delete ${fullNameLF} because they have records.`);

        if (!confirm(`Delete profile for ${fullNameLF}?`)) return;

        athletes = athletes.filter(a => a.id != id);
        saveAthletes();
        populateAthleteDropdown();
        renderAthleteList();

        if (editingAthleteId == id) {
            editingAthleteId = null;
            newAthleteID.value = '';
            newAthleteFirstName.value = '';
            newAthleteLastName.value = '';
            newAthleteLastName.value = '';
            if (dobPicker) dobPicker.clear();
            else newAthleteDOB.value = '';
            newAthleteGender.value = '';
            athleteSubmitBtn.innerHTML = '<span>+ Save Athlete</span>';
            athleteSubmitBtn.style.background = '';
        }
    }

    // --- Athlete Sorting State ---
    let athleteSortField = 'lastName';
    let athleteSortOrder = 'asc';

    window.sortAthletes = function (field) {
        if (athleteSortField === field) {
            athleteSortOrder = athleteSortOrder === 'asc' ? 'desc' : 'asc';
        } else {
            athleteSortField = field;
            athleteSortOrder = 'asc';
        }
        renderAthleteList();
    };

    function renderAthleteList() {
        if (!athleteListBody) return;
        athleteListBody.innerHTML = '';

        try {
            // Sorting Logic
            if (athletes && athletes.length > 0) {
                athletes.sort((a, b) => {
                    if (!a || !b) return 0;
                    let valA = (a[athleteSortField] || '').toString().toLowerCase();
                    let valB = (b[athleteSortField] || '').toString().toLowerCase();

                    if (athleteSortField === 'dob') {
                        valA = a.dob ? new Date(a.dob).getTime() : 0;
                        valB = b.dob ? new Date(b.dob).getTime() : 0;
                    }

                    if (valA < valB) return athleteSortOrder === 'asc' ? -1 : 1;
                    if (valA > valB) return athleteSortOrder === 'asc' ? 1 : -1;
                    return 0;
                });

                athletes.forEach(a => {
                    if (!a) return;
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${a.idNumber || '-'}</td>
                        <td style="font-weight:600;">${a.lastName}</td>
                        <td>${a.firstName}</td>
                        <td>${a.dob ? new Date(a.dob).toLocaleDateString('en-GB') : '-'}</td>
                        <td>${a.gender || '-'}</td>
                        <td>
                            <button class="btn-icon edit edit-athlete-btn" data-id="${a.id}" title="Edit">✏️</button>
                            <button class="btn-icon delete delete-athlete-btn" data-id="${a.id}" title="Delete">🗑️</button>
                        </td>
                    `;
                    athleteListBody.appendChild(tr);
                });
            } else {
                athleteListBody.innerHTML = '<tr><td colspan="6" style="text-align:center;">No athletes found.</td></tr>';
            }
        } catch (e) {
            console.error("Error rendering athlete list:", e);
            athleteListBody.innerHTML = `<tr><td colspan="6" style="color:red;">Error loading athletes: ${e.message}</td></tr>`;
        }
    }

    function saveAthletes() { localStorage.setItem('tf_athletes', JSON.stringify(athletes)); }


    // --- Enhanced Events ---
    function handleEventSubmit(e) {
        e.preventDefault();
        const name = newEventName.value.trim();
        const specs = newEventSpecs.value.trim();
        const desc = newEventSecondary.value.trim();
        const notes = newEventNotes.value.trim();
        const isCombined = newEventCombined.checked;
        const isRelay = newEventRelay.checked;

        let subEvents = [];
        if (isCombined) {
            const inputs = subEventsContainer.querySelectorAll('.sub-event-input');
            inputs.forEach(input => {
                if (input.value) subEvents.push(input.value);
            });
        }

        if (editingEventId) {
            const idx = events.findIndex(ev => ev.id == editingEventId);
            if (idx !== -1) {
                const ev = events[idx]; // Define ev here
                const oldName = ev.name;
                if (oldName !== name && events.some(event => event.name === name)) { // Renamed ev to event to avoid conflict
                    return alert('Event Name already exists!');
                }

                ev.name = name;
                ev.specs = specs;
                ev.descriptionEn = desc;
                ev.notes = notes;
                ev.isCombined = isCombined;
                ev.isRelay = isRelay;
                ev.subEvents = subEvents;

                records.forEach(r => {
                    if (r.event === oldName) r.event = name;
                });
            }

            editingEventId = null;
            eventSubmitBtn.innerHTML = '<span>+ Add Event</span>';
            eventSubmitBtn.style.background = '';
        } else {
            // Create New
            if (events.some(ev => ev.name.toLowerCase() === name.toLowerCase())) {
                return alert('Event already exists!');
            }
            events.push({
                id: Date.now(),
                name: name,
                descriptionEn: desc,
                specs: specs,
                notes: notes,
                isCombined: isCombined,
                isRelay: isRelay,
                subEvents: subEvents
            });
        }

        saveEvents();
        saveRecords();
        populateYearDropdown(); // Added this line
        populateEventDropdowns();
        renderEventList();
        renderReports();

        // Reset Form
        newEventName.value = '';
        newEventSecondary.value = '';
        newEventSpecs.value = '';
        newEventNotes.value = '';
        newEventCombined.checked = false;
        newEventRelay.checked = false;
        newEventSubCount.value = '';
        newEventSubCount.disabled = true;
        subEventsContainer.innerHTML = '';
        subEventsContainer.style.display = 'none';

        newEventName.focus();
    }

    function editEvent(id) {
        const ev = events.find(e => e.id == id);
        if (!ev) return;

        newEventName.value = ev.name;
        newEventSecondary.value = ev.descriptionEn || '';
        newEventSpecs.value = ev.specs || '';
        newEventNotes.value = ev.notes || '';
        newEventCombined.checked = ev.isCombined || false;
        newEventRelay.checked = ev.isRelay || false;

        editingEventId = id; // Set ID early for filter logic

        if (ev.isCombined) {
            newEventSubCount.disabled = false;
            const subs = ev.subEvents || [];
            const count = subs.length; // Define count here
            if (count > 0) {
                subEventsContainer.style.display = 'flex';
                // Create Options once
                let options = '<option value="" disabled selected>Select Event</option>';
                // Filter out Combined and Relay events from being sub-events to prevent recursion/complexity
                // Also filter out the event being edited (if any) to prevent self-reference
                const availableEvents = events.filter(e => !e.isCombined && !e.isRelay && e.id != editingEventId);

                availableEvents.sort((a, b) => a.name.localeCompare(b.name));

                // Build options string once
                // We'll insert selected attribute dynamically? No, harder with string.
                // Better to build DOM nodes or just set value after.

                subEventsContainer.innerHTML = '';
                subEventsContainer.style.display = 'flex';

                subs.forEach((subName, i) => {
                    const div = document.createElement('div');
                    div.className = 'form-group';
                    div.style.flex = '1 1 45%';
                    div.style.minWidth = '150px';

                    // Build options for this specific select
                    let theseOptions = options; // Start with base

                    // Construct Select
                    const select = document.createElement('select');
                    select.className = 'sub-event-input';
                    select.required = true;
                    select.style.width = '100%';

                    // Add default
                    const defOpt = document.createElement('option');
                    defOpt.value = "";
                    defOpt.disabled = true;
                    defOpt.textContent = "Select Event";
                    if (!subName) defOpt.selected = true;
                    select.appendChild(defOpt);

                    availableEvents.forEach(ae => {
                        const opt = document.createElement('option');
                        opt.value = ae.name;
                        opt.textContent = ae.name;
                        if (ae.name === subName) opt.selected = true;
                        select.appendChild(opt);
                    });

                    div.innerHTML = `<label style="font-size:0.75rem;">Event ${i + 1}</label>`;
                    div.appendChild(select);

                    subEventsContainer.appendChild(div);
                });
            } else { // Close if (count > 0)
                newEventSubCount.disabled = true;
                newEventSubCount.value = '';
                subEventsContainer.innerHTML = '';
                subEventsContainer.style.display = 'none';
            }
        } else {
            newEventSubCount.disabled = true;
            newEventSubCount.value = '';
            subEventsContainer.innerHTML = '';
            subEventsContainer.style.display = 'none';
        }

        editingEventId = id;
        newEventName.focus();
        eventSubmitBtn.innerHTML = '<span>Update Event</span>';
        eventSubmitBtn.style.background = 'linear-gradient(135deg, var(--warning), #f59e0b)';
    }

    function deleteEvent(id) {
        const ev = events.find(e => e.id == id);
        if (!ev) return;

        const isUsed = records.some(r => r.event === ev.name);
        if (isUsed) return alert(`Cannot delete "${ev.name}" because it has associated records.`);

        if (!confirm(`Delete event "${ev.name}"?`)) return;

        events = events.filter(e => e.id != id);
        saveEvents();
        populateEventDropdowns();
        renderEventList();

        if (editingEventId == id) {
            editingEventId = null;
            newEventName.value = '';
            newEventSecondary.value = '';
            newEventSpecs.value = '';
            newEventNotes.value = '';
            newEventCombined.checked = false;
            newEventRelay.checked = false;
            eventSubmitBtn.innerHTML = '<span>+ Add Event</span>';
            eventSubmitBtn.style.background = '';
        }
    }

    function saveCountries() { localStorage.setItem('tf_countries', JSON.stringify(countries)); }

    function populateCountryDropdown() {
        if (!countryInput) return;
        let html = '<option value="" disabled>Select Country</option>';
        // Sort safely
        const safeCountries = Array.isArray(countries) ? countries : [];
        safeCountries.sort((a, b) => a.localeCompare(b)).forEach(c => {
            const isSelected = c === 'Ελλάδα' ? 'selected' : '';
            html += `<option value="${c}" ${isSelected}>${c}</option>`;
        });
        countryInput.innerHTML = html;
    }

    function handleCountrySubmit(e) {
        e.preventDefault();
        const name = newCountryName.value.trim();
        if (!name) return;

        if (countries.some(c => c.toLowerCase() === name.toLowerCase())) {
            return alert('Country already exists!');
        }

        countries.push(name);
        countries.sort();
        saveCountries();
        renderCountryList();
        populateCountryDropdown();
        newCountryName.value = '';
    }

    function deleteCountry(name) {
        if (!confirm(`Delete ${name}?`)) return;
        countries = countries.filter(c => c !== name);
        saveCountries();
        renderCountryList();
        populateCountryDropdown();
    }

    function renderCountryList() {
        if (!countryListBody) return;
        countryListBody.innerHTML = '';
        const safeCountries = Array.isArray(countries) ? countries : [];
        safeCountries.forEach(c => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${c}</td>
                <td style="text-align:right;">
                    <button class="btn-icon delete delete-country-btn" data-country="${c}" title="Delete">🗑️</button>
                </td>
            `;
            countryListBody.appendChild(tr);
        });
    }

    function renderEventList() {
        if (!eventListBody) return;
        eventListBody.innerHTML = '';
        // Sort by Name
        events.sort((a, b) => a.name.localeCompare(b.name));

        events.forEach(ev => {
            const isUsed = records.some(r => r.event === ev.name);
            const tr = document.createElement('tr');

            let types = [];
            if (ev.isCombined) {
                const count = ev.subEvents ? ev.subEvents.length : 0;
                types.push(`<span style="background:var(--accent); color:black; padding:2px 6px; border-radius:4px; font-size:0.75rem;">Combined (${count})</span>`);
            }
            if (ev.isRelay) types.push('<span style="background:var(--primary); color:white; padding:2px 6px; border-radius:4px; font-size:0.75rem;">Relay</span>');

            tr.innerHTML = `
                <td style="font-weight:600;">${ev.name}</td>
                <td style="font-size:0.9rem; color:var(--text-muted);">${ev.descriptionEn || '-'}</td>
                <td style="font-size:0.9rem; color:var(--text-muted); white-space:pre-wrap;">${ev.specs || '-'}</td>
                <td style="font-size:0.9rem; color:var(--text-muted); white-space:pre-wrap;">${ev.notes || '-'}</td>
                <td>${types.join(' ') || '-'}</td>
                <td>
                    <button class="btn-icon edit edit-event-btn" data-id="${ev.id}" title="Edit">✏️</button>
                    <button class="btn-icon delete delete-event-btn" data-id="${ev.id}" 
                        title="${isUsed ? 'In use' : 'Delete'}" ${isUsed ? 'disabled' : ''}>🗑️</button>
                </td>
            `;
            eventListBody.appendChild(tr);
        });
    }

    function saveEvents() { localStorage.setItem('tf_events', JSON.stringify(events)); }

    // --- Records ---
    function saveHistory() { localStorage.setItem('tf_history', JSON.stringify(history)); }

    // --- Records ---


    function handleFormSubmit(e) {
        e.preventDefault();
        try {
            const raceName = raceNameInput ? raceNameInput.value.trim() : '';
            const idr = idrInput ? idrInput.value.trim() : '';

            // --- Age Validation Enforcement ---
            const selectedAthlete = athleteInput ? athleteInput.value : '';
            const selectedAgeGroup = ageGroupInput ? ageGroupInput.value : '';
            const selectedDate = dateInput ? dateInput.value : '';

            if (selectedAthlete && selectedDate) {
                const athlete = athletes.find(a => `${a.lastName}, ${a.firstName}` === selectedAthlete);
                if (athlete && athlete.dob) {
                    const calculatedGroup = calculateAgeGroup(athlete.dob, selectedDate);
                    // Check Mismatch
                    if (selectedAgeGroup !== calculatedGroup) {
                        const exactAge = getExactAge(athlete.dob, selectedDate);
                        const confirmMsg = `Age Category Mismatch!\n\nAthlete Age: ${exactAge}\nCalculated Category: ${calculatedGroup || 'Under 35'}\nSelected Category: ${selectedAgeGroup || 'None'}\n\nDo you want to save anyway?`;

                        if (!confirm(confirmMsg)) {
                            return; // User cancelled
                        }
                    }
                }
            }

            const newRecord = {
                id: (editingId || editingHistoryId) ? (editingId || editingHistoryId) : Date.now(),
                event: evtInput ? evtInput.value : '',
                gender: genderInput ? genderInput.value : '',
                ageGroup: ageGroupInput ? ageGroupInput.value : '',
                athlete: athleteInput ? athleteInput.value : '',
                raceName: raceName,
                idr: idr,
                notes: notesInput ? notesInput.value.trim() : '',
                mark: markInput ? markInput.value : '',
                wind: windInput ? windInput.value : '',
                date: dateInput ? dateInput.value : '',
                town: townInput ? townInput.value : '',
                country: countryInput ? countryInput.value : ''
            };

            if (editingHistoryId) {
                // Update History Record
                const index = history.findIndex(r => r.id === editingHistoryId);
                if (index !== -1) {
                    // Keep original archive timestamp
                    newRecord.archivedAt = history[index].archivedAt;
                    history[index] = newRecord;
                    saveHistory();
                    renderHistoryList();
                }
                submitBtn.querySelector('span').textContent = 'History Updated! ✓';
                setTimeout(() => {
                    cancelEdit();
                    switchTab('history');
                }, 1000);
            } else if (editingId) {
                // Edit Live Record -> Archive Old Version
                const index = records.findIndex(r => r.id === editingId);
                if (index !== -1) {
                    const oldRecord = { ...records[index] };
                    oldRecord.archivedAt = new Date().toISOString();
                    oldRecord.originalId = oldRecord.id;
                    // Use integer ID to avoid float precision issues in DOM
                    oldRecord.id = Date.now() + Math.floor(Math.random() * 100000);

                    history.unshift(oldRecord);
                    saveHistory();
                    renderHistoryList();

                    records[index] = newRecord;
                }
                submitBtn.querySelector('span').textContent = 'Updated & Archived! ✓';
                setTimeout(() => cancelEdit(), 1000);
            } else {
                records.unshift(newRecord);
                submitBtn.querySelector('span').textContent = 'Logged! ✓';
                setTimeout(() => submitBtn.querySelector('span').textContent = 'Log Record', 1500);
                recordForm.reset();
                if (datePicker) {
                    datePicker.setDate(new Date());
                } else if (dateInput && dateInput.type === 'date') {
                    dateInput.valueAsDate = new Date();
                } else if (dateInput) {
                    dateInput.value = new Date().toISOString().split('T')[0];
                }
            }
            saveRecords();
            populateYearDropdown();
            renderReports();
            renderAthleteList();
        } catch (error) {
            console.error("Form Submit Error:", error);
            alert("Error saving record: " + error.message);
        }
    }

    function renderHistoryList() {
        const tbody = document.getElementById('historyListBody');
        const empty = document.getElementById('historyEmptyState');
        if (!tbody) return;

        tbody.innerHTML = '';
        if (history.length === 0) {
            if (empty) empty.classList.remove('hidden');
            return;
        }
        if (empty) empty.classList.add('hidden');

        history.forEach(r => {
            const tr = document.createElement('tr');
            // Find immediate successor (The record that replaced this one)
            // 1. Get all archived versions of this record
            const versions = history.filter(h => h.originalId === r.originalId).sort((a, b) => new Date(a.archivedAt) - new Date(b.archivedAt));
            const currentIndex = versions.findIndex(v => v.id === r.id);

            let successor = null;
            let successorLabel = '';

            if (currentIndex !== -1 && currentIndex < versions.length - 1) {
                // Formatting: Successor is the NEXT history item (intermediate version)
                successor = versions[currentIndex + 1];
                successorLabel = 'REPLACED BY (INTERMEDIATE VERSION)';
            } else {
                // Successor is the current Live record
                successor = records.find(curr => curr.id === r.originalId);
                successorLabel = 'REPLACED BY (CURRENT LIVE VERSION)';
            }

            tr.innerHTML = `
                <td style="text-align:center;">
                    ${successor ? `<button class="btn-icon expand-btn" data-id="${r.id}" style="font-weight:bold; color:var(--primary); cursor:pointer;">+</button>` : ''}
                </td>
                <td>${r.event}</td>
                <td style="font-weight:600;">${r.athlete}</td>
                <td>${r.gender || '-'}</td>
                <td>${r.ageGroup || '-'}</td>
                <td>${r.mark}</td>
                <td>${r.idr || '-'}</td>
                <td>${r.wind || '-'}</td>
                <td>${new Date(r.date).toLocaleDateString('en-GB')}</td>
                <td>${r.raceName || '-'}</td>
                <td style="font-size:0.85em; color:var(--text-muted);">${new Date(r.archivedAt).toLocaleString('en-GB')}</td>
                 <td>
                    <button class="btn-icon edit edit-history-btn" data-id="${r.id}" title="Edit Archived">✏️</button>
                    <button class="btn-icon delete delete-history-btn" data-id="${r.id}" title="Delete Permanent">🗑️</button>
                </td>
            `;
            tbody.appendChild(tr);

            if (successor) {
                const trDetail = document.createElement('tr');
                trDetail.className = 'detail-row hidden';
                trDetail.id = `detail-hist-${r.id}`;
                trDetail.innerHTML = `
                    <td colspan="1" style="border-top:none; background:transparent;"></td>
                    <td colspan="11" style="padding: 8px 10px; border-top:none; background: rgba(16, 185, 129, 0.1);">
                        <div style="display:flex; gap:1rem; align-items:center;">
                            <span style="font-weight:bold; color:var(--success);">${successor.athlete}</span>
                            <span>${successor.mark} (${successor.wind || '-'})</span>
                            <span>| ${new Date(successor.date).toLocaleDateString('en-GB')}</span>
                            <span>| ${successor.raceName || '-'}</span>
                        </div>
                    </td>
                `;
                tbody.appendChild(trDetail);
            }
        });
    }

    function editHistory(id) {
        switchTab('log');
        // Use loose equality to handle potential string/number mismatches from DOM
        const r = history.find(item => item.id == id);
        if (!r) return;

        if (evtInput) evtInput.value = r.event;
        if (athleteInput) athleteInput.value = r.athlete;
        if (genderInput) genderInput.value = r.gender || '';
        if (ageGroupInput) ageGroupInput.value = r.ageGroup || '';
        if (raceNameInput) raceNameInput.value = r.raceName || '';
        if (notesInput) notesInput.value = r.notes || '';
        if (markInput) markInput.value = r.mark;
        if (windInput) windInput.value = r.wind || '';

        if (dateInput) {
            if (datePicker) datePicker.setDate(r.date);
            else dateInput.value = r.date;
        }

        if (townInput) townInput.value = r.town || '';
        if (countryInput) countryInput.value = r.country || '';

        editingHistoryId = id;
        editingId = null; // Ensure we are not editing a live record

        formTitle.textContent = 'Edit Archived Record';
        formTitle.style.color = 'var(--text-muted)';
        submitBtn.querySelector('span').textContent = 'Update Archive';
        submitBtn.style.background = 'linear-gradient(135deg, #6366f1, #8b5cf6)'; // Purple for history
        cancelBtn.classList.remove('hidden');
        recordForm.scrollIntoView({ behavior: 'smooth' });
    }

    function deleteHistory(id) {
        if (!confirm('Permanently delete this archived record?')) return;
        history = history.filter(h => h.id != id);
        saveHistory();
        renderHistoryList();
    }

    function handleMixedGenderVisibility(eventName) {
        const genderSelect = document.getElementById('gender');
        const optMixed = document.getElementById('optMixed');
        if (!genderSelect || !optMixed) return;

        // Find event definition
        const ev = events.find(e => e.name === eventName);
        const isRelay = ev ? ev.isRelay : false;

        if (isRelay) {
            optMixed.hidden = false;
            optMixed.disabled = false;
        } else {
            optMixed.hidden = true;
            optMixed.disabled = true;
            // Reset if Mixed was selected
            if (genderSelect.value === 'Mixed') {
                genderSelect.value = '';
            }
        }
    }

    function editRecord(id) {
        switchTab('log');
        const r = records.find(item => item.id === id);
        if (!r) return;

        if (evtInput) {
            evtInput.value = r.event;
            handleMixedGenderVisibility(r.event); // Update Mixed visibility
        }
        if (athleteInput) athleteInput.value = r.athlete;
        if (genderInput) genderInput.value = r.gender || '';
        if (ageGroupInput) ageGroupInput.value = r.ageGroup || '';
        if (raceNameInput) raceNameInput.value = r.raceName || '';
        if (notesInput) notesInput.value = r.notes || '';
        if (markInput) markInput.value = r.mark;
        if (windInput) windInput.value = r.wind || '';

        if (dateInput) {
            if (datePicker) datePicker.setDate(r.date);
            else dateInput.value = r.date;
        }

        if (townInput) townInput.value = r.town || '';
        if (countryInput) countryInput.value = r.country || '';

        editingId = id;
        editingHistoryId = null;

        formTitle.textContent = 'Edit Record (Archives Old)';
        submitBtn.querySelector('span').textContent = 'Update & Archive';
        submitBtn.style.background = 'linear-gradient(135deg, var(--warning), #f59e0b)';
        cancelBtn.classList.remove('hidden');
        recordForm.scrollIntoView({ behavior: 'smooth' });
    }

    function cancelEdit() {
        const wasEditingHistory = !!editingHistoryId;
        editingId = null;
        editingHistoryId = null;
        recordForm.reset();

        if (datePicker) {
            datePicker.setDate(new Date());
        } else if (dateInput && dateInput.type === 'date') {
            dateInput.valueAsDate = new Date();
        } else if (dateInput) {
            dateInput.value = new Date().toISOString().split('T')[0];
        }

        formTitle.textContent = 'Log New Record';
        formTitle.style.color = '';
        submitBtn.querySelector('span').textContent = 'Log Record';
        submitBtn.style.background = '';
        cancelBtn.classList.add('hidden');

        if (wasEditingHistory) switchTab('history');
    }

    function deleteRecord(id) {
        if (!confirm('Delete this record?')) return;
        records = records.filter(r => r.id !== id);
        if (editingId === id) cancelEdit();
        saveRecords();
        populateYearDropdown();
        renderReports();
        renderEventList();
        renderAthleteList();
    }

    function clearAllData() {
        if (confirm('Are you sure you want to clear ALL data?')) {
            records = [];
            localStorage.clear();
            location.reload();
        }
    }

    function saveRecords() { localStorage.setItem('tf_records', JSON.stringify(records)); }

    function genderFilterChange() { renderReports(); }

    function getFilteredRecords() {
        const eVal = filterEvent ? filterEvent.value : 'all';
        const gVal = filterGender ? filterGender.value : 'all';
        const aVal = filterAge ? filterAge.value : 'all';
        const yVal = filterYear ? filterYear.value : 'all';
        const mVal = filterAgeMismatch ? filterAgeMismatch.value : 'all';

        const filtered = records.filter(r => {
            const matchesEvent = eVal === 'all' || r.event === eVal;
            const matchesGender = gVal === 'all' || r.gender === gVal;
            const matchesAge = aVal === 'all' || r.ageGroup === aVal;

            // Year filter
            let matchesYear = true;
            if (yVal !== 'all') {
                const rYear = r.date ? new Date(r.date).getFullYear().toString() : '';
                matchesYear = rYear === yVal;
            }

            // Age Mismatch Filter
            let matchesMismatch = true;
            if (mVal !== 'all') {
                const athlete = athletes.find(a => `${a.lastName}, ${a.firstName}` === r.athlete);
                let isMismatch = false;
                if (r.ageGroup && athlete && athlete.dob && r.date) {
                    const calculatedGroup = calculateAgeGroup(athlete.dob, r.date);
                    if (r.ageGroup !== calculatedGroup) {
                        isMismatch = true;
                    }
                }

                if (mVal === 'issue') {
                    matchesMismatch = isMismatch;
                } else if (mVal === 'valid') {
                    matchesMismatch = !isMismatch;
                }
            }

            return matchesEvent && matchesGender && matchesAge && matchesYear && matchesMismatch;
        });

        // Apply Sorting
        const sortBy = document.getElementById('sortBy');
        const sortVal = sortBy ? sortBy.value : 'dateDesc';

        filtered.sort((a, b) => {
            switch (sortVal) {
                case 'dateAsc':
                    return new Date(a.date) - new Date(b.date);
                case 'dateDesc':
                    return new Date(b.date) - new Date(a.date);
                case 'athleteAsc':
                    return a.athlete.localeCompare(b.athlete);
                case 'eventAsc':
                    return a.event.localeCompare(b.event);
                case 'markAsc':
                    // Simple string comparison for now, or number if possible
                    // Ideally we'd parse this, but formats vary (10.00 vs 10:00.00)
                    return a.mark.toString().localeCompare(b.mark.toString(), undefined, { numeric: true });
                case 'markDesc':
                    return b.mark.toString().localeCompare(a.mark.toString(), undefined, { numeric: true });
                case 'ageGroupAsc':
                    // Parse starting age, handling "Open", empty, etc.
                    return (parseInt(a.ageGroup) || 0) - (parseInt(b.ageGroup) || 0);
                case 'ageGroupDesc':
                    return (parseInt(b.ageGroup) || 0) - (parseInt(a.ageGroup) || 0);
                default:
                    return new Date(b.date) - new Date(a.date);
            }
        });

        return filtered;
    }

    function getExactAge(dobStr, eventDateStr) {
        const dob = new Date(dobStr);
        const evt = new Date(eventDateStr);
        if (isNaN(dob) || isNaN(evt)) return null;
        let age = evt.getFullYear() - dob.getFullYear();
        const m = evt.getMonth() - dob.getMonth();
        if (m < 0 || (m === 0 && evt.getDate() < dob.getDate())) {
            age--;
        }
        return age;
    }

    // Helper to toggle age in-place temporarily
    window.showExactAge = function (el, age) {
        if (el.dataset.isToggled === 'true') return;

        const originalText = el.textContent;

        // Change to Success State
        el.dataset.isToggled = 'true';
        el.textContent = age;
        el.style.backgroundColor = 'var(--success)'; // Green background
        el.style.borderColor = 'var(--success)';
        el.style.color = 'white';
        el.style.transform = 'scale(1.1)';
        el.style.transition = 'all 0.2s';

        setTimeout(() => {
            // Revert
            el.dataset.isToggled = 'false';
            el.textContent = originalText;
            el.style.backgroundColor = '';
            el.style.borderColor = '';
            el.style.color = '';
            el.style.transform = '';
        }, 2000);
    };

    function renderReports() {
        if (!reportTableBody) return;
        reportTableBody.innerHTML = '';

        const filtered = getFilteredRecords();

        if (filtered.length === 0) {
            emptyState.classList.remove('hidden');
        } else {
            emptyState.classList.add('hidden');
            // Sort applied in getFilteredRecords

            filtered.forEach(r => {
                const tr = document.createElement('tr');
                const hasNotes = r.notes && r.notes.trim().length > 0;

                // Find athlete for Age Validation
                const athlete = athletes.find(a => `${a.lastName}, ${a.firstName}` === r.athlete);
                let ageDisplay = r.ageGroup || '-';

                if (r.ageGroup && athlete && athlete.dob && r.date) {
                    const calculatedGroup = calculateAgeGroup(athlete.dob, r.date);
                    // r.ageGroup is like "35", calculatedGroup is "35" or null (if <35)
                    // Mismatch if stored group != calculated group
                    if (r.ageGroup !== calculatedGroup) {
                        const exactAge = getExactAge(athlete.dob, r.date);
                        ageDisplay = `<span class="age-indicator" title="Click to see exact age" style="cursor:pointer;" onclick="showExactAge(this, '${exactAge}')">${r.ageGroup}</span>`;
                    }
                }

                tr.innerHTML = `
                    <td style="text-align:center;">
                        ${hasNotes ? `<button class="btn-icon expand-btn" data-id="${r.id}" style="font-weight:bold; color:var(--primary); cursor:pointer;">+</button>` : ''}
                    </td>
                    <td style="font-weight:600;">${r.event}</td>
                    <td>${r.athlete}</td>
                    <td>${r.gender || '-'}</td>
                    <td>${ageDisplay}</td>
                    <td style="font-weight:700; color:var(--accent);">${r.mark}</td>
                    <td>${r.idr || '-'}</td>
                    <td>${r.wind || '-'}</td>
                    <td>${new Date(r.date).toLocaleDateString('en-GB')}</td>
                    <td>${r.raceName || ''}</td>
                    <td>
                        <button class="btn-icon edit edit-btn" data-id="${r.id}" title="Edit">✏️</button>
                        <button class="btn-icon delete delete-btn" data-id="${r.id}" title="Delete">🗑️</button>
                    </td>
                `;
                reportTableBody.appendChild(tr);

                if (hasNotes) {
                    const trDetail = document.createElement('tr');
                    trDetail.className = 'detail-row hidden';
                    trDetail.id = `detail-${r.id}`;
                    trDetail.style.backgroundColor = 'rgba(139, 92, 246, 0.05)';
                    trDetail.innerHTML = `
                        <td colspan="5" style="border-top:none; background:transparent;"></td>
                        <td colspan="6" style="padding: 8px 10px; font-style: italic; color: var(--text-muted); border-top:none;">
                            <strong>Επιδόσεις:</strong> ${r.notes}
                        </td>
                    `;
                    reportTableBody.appendChild(trDetail);
                }
            });
        }
    }

    function exportToExcel() {
        const data = getFilteredRecords();
        if (!data.length) return alert('No data to export!');
        let csv = 'Event,Athlete,Gender,Age Group,Mark,Wind,Date,Location,Race Name,Notes\n';
        data.forEach(r => {
            csv += `"${r.event}","${r.athlete}","${r.gender || ''}","${r.ageGroup || ''}","${r.mark}","${r.wind || ''}","${r.date}","${r.location}","${r.raceName || ''}","${r.notes || ''}"\n`;
        });
        const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `track_records.csv`;
        link.click();
        URL.revokeObjectURL(url);
    }

    function exportToHTML() {
        const table = document.getElementById('reportTable').cloneNode(true);
        table.querySelectorAll('.actions-col').forEach(e => e.remove());
        const html = `<html><head><title>Report</title><style>body{font-family:sans-serif}table{width:100%;border-collapse:collapse}td,th{border:1px solid #ddd;padding:8px}</style></head><body><h1>Greek Masters Track & Field Records</h1><h2 style="text-align:center;">OUTDOORS</h2>${table.outerHTML}</body></html>`;
        const blob = new Blob([html], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'report.html';
        link.click();
    }

    async function exportToPDF() {
        if (!window.jspdf) return alert('PDF library not loaded.');
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        // Use embedded Base64 Font (Reliable "Nuclear Option")
        if (typeof ROBOTO_BASE64 !== 'undefined') {
            const fontName = 'Roboto-Regular.ttf';
            doc.addFileToVFS(fontName, ROBOTO_BASE64);
            doc.addFont(fontName, 'Roboto', 'normal');
            doc.setFont('Roboto');
            console.log("Using embedded Roboto font.");
        } else {
            console.error("ROBOTO_BASE64 is undefined.");
            // Fallback or alert
            alert("Error: Embedded font not found.");
        }

        const data = getFilteredRecords().map(r => [r.event, r.athlete, r.gender || '-', r.ageGroup || '-', r.mark, r.wind || '-', r.date, r.raceName || '-', r.notes || '-']);

        doc.setFontSize(18);
        doc.text("Greek Masters Track & Field Records", 14, 15);

        doc.setFontSize(10);
        doc.autoTable({
            head: [['Event', 'Athlete', 'Gender', 'Age', 'Mark', 'Wind', 'Date', 'Race Name', 'Notes']],
            body: data,
            startY: 20,
            theme: 'grid',
            headStyles: { fillColor: [139, 92, 246] },
            styles: { font: 'Roboto', fontStyle: 'normal' } // Apply Roboto
        });
        doc.save('track_report.pdf');
    }

    function exportDatabase() {
        const db = {
            version: 4,
            exportedAt: new Date().toISOString(),
            events: events,
            records: records,
            athletes: athletes
        };
        const blob = new Blob([JSON.stringify(db, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'track_data.json';
        link.click();
        URL.revokeObjectURL(url);
    }

    function handleAthleteImport(e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function (e) {
            try {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(firstSheet);

                let importedCount = 0;
                jsonData.forEach(row => {
                    // Normalize keys to lowercase for flexible matching
                    const normalizedRow = {};
                    Object.keys(row).forEach(key => {
                        normalizedRow[key.toString().toLowerCase().trim().replace(/\s+/g, '')] = row[key];
                    });

                    // Map fields
                    // Expected: First Name, Last Name, Gender, DOB, Club/Team
                    const firstName = normalizedRow['firstname'] || normalizedRow['name'] || normalizedRow['fname'];
                    const lastName = normalizedRow['lastname'] || normalizedRow['surname'] || normalizedRow['lname'];
                    const genderVal = normalizedRow['gender'] || normalizedRow['sex'];
                    const dobVal = normalizedRow['dob'] || normalizedRow['dateofbirth'] || normalizedRow['birthdate'];
                    const idVal = normalizedRow['id'] || normalizedRow['code'];

                    if (!firstName || !lastName) return; // Skip if no name

                    // Parse Gender
                    let gender = '';
                    if (genderVal) {
                        const g = genderVal.toString().toLowerCase();
                        if (g.startsWith('m') || g === 'andr') gender = 'Male';
                        if (g.startsWith('f') || g === 'gyn') gender = 'Female';
                    }

                    // Parse DOB (Excel dates are often numbers)
                    let dob = '';
                    if (dobVal) {
                        if (typeof dobVal === 'number') {
                            // Excel serial date to JS Date
                            const date = new Date(Math.round((dobVal - 25569) * 864e5));
                            dob = date.toISOString().split('T')[0];
                        } else {
                            // Try to parse string
                            const date = new Date(dobVal);
                            if (!isNaN(date)) dob = date.toISOString().split('T')[0];
                        }
                    }

                    // Check duplicates (by Name + DOB or ID)
                    const exists = athletes.some(a =>
                        (idVal && a.id == idVal) ||
                        (a.firstName.toLowerCase() === firstName.toString().toLowerCase() &&
                            a.lastName.toLowerCase() === lastName.toString().toLowerCase() &&
                            (!dob || a.dob === dob))
                    );

                    if (!exists) {
                        const newAthlete = {
                            id: idVal ? idVal.toString() : Date.now() + Math.floor(Math.random() * 100000),
                            firstName: firstName.toString(),
                            lastName: lastName.toString(),
                            gender: gender,
                            dob: dob,
                            club: normalizedRow['club'] || normalizedRow['team'] || ''
                        };
                        athletes.push(newAthlete);
                        importedCount++;
                    }
                });

                if (importedCount > 0) {
                    saveAthletes();
                    renderAthleteList();
                    populateAthleteDropdown();
                    alert(`Successfully imported ${importedCount} athletes!`);
                } else {
                    alert('No new athletes found or file format not recognized.');
                }

            } catch (err) {
                console.error(err);
                alert('Error processing file: ' + err.message);
            }
            // Reset input
            athleteImportFile.value = '';
        };
        reader.readAsArrayBuffer(file);
    }
    function importRecordsFromFile(file) {
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(firstSheet, { defval: "" });

                if (jsonData.length === 0) {
                    alert('File appears to be empty.');
                    return;
                }

                if (!confirm(`Found ${jsonData.length} rows. Import records?`)) return;

                let importedCount = 0;
                jsonData.forEach(row => {
                    // Normalization
                    let r = {};
                    Object.keys(row).forEach(k => {
                        r[k.trim().toLowerCase().replace(/[^a-z0-9]/g, '')] = row[k];
                    });

                    // Mapping
                    const event = row['Event'] || row['event'] || r['event'] || '';
                    // Expanded Athlete Check:
                    // Checks: "Athlete", "Athlete Name", "Athletes Name", "Full Name", "Name" and their normalized versions.
                    let rawName = row['Athlete'] || row['Athlete Name'] || row['Athletes Name'] || row['Full Name'] ||
                        r['athlete'] || r['athletename'] || r['athletesname'] || r['fullname'] ||
                        row['Name'] || '';

                    let finalAthleteName = rawName.trim();

                    // Smart Link to Existing Athletes
                    if (finalAthleteName) {
                        const cleanImport = finalAthleteName.toLowerCase().replace(/,/g, '').replace(/\s+/g, ' ').trim();

                        // Try to find a match in the existing athletes list
                        const match = athletes.find(a => {
                            const first = (a.firstName || '').toLowerCase().trim();
                            const last = (a.lastName || '').toLowerCase().trim();

                            const fl = `${first} ${last}`;
                            const lf = `${last} ${first}`;
                            const l_f = `${last} ${first}`; // Comma removed in cleanImport check

                            // Check against "First Last", "Last First", etc.
                            return cleanImport === fl || cleanImport === lf || cleanImport === l_f;
                        });

                        if (match) {
                            // If found, use the system canonical name: "Last, First"
                            finalAthleteName = `${match.lastName}, ${match.firstName}`;
                        } else {
                            // If not found, try to normalize "First Last" to "Last, First" heuristically
                            if (!finalAthleteName.includes(',')) {
                                const parts = finalAthleteName.split(' ');
                                if (parts.length >= 2) {
                                    // Conservative guess: Last element is Last Name? 
                                    // Or First element is First Name?
                                    // Let's assume input is "First Last" which is standard Excel, so we flip to "Last, First"
                                    // ONLY if we didn't find a direct match.
                                    // actually, let's look for partial matches? No, unsafe.
                                    // Let's just flip it and hope, OR keep as is. 
                                    // User said "names are almost same".
                                    // If we swap blindly we might mess up "Van Der Sar".
                                    // Let's just keep as is if no match found, BUT we can try one swap attempt to match.

                                    // Actually, if we didn't match an existing athlete, we can't be sure.
                                    // But to "connect" them, they MUST match the string value in the option list.
                                    // The option list is "Last, First".
                                }
                            }
                        }
                    }

                    const gender = row['Gender'] || row['gender'] || r['gender'] || row['Sex'] || '';
                    const ageGroup = row['Age Group'] || row['Age'] || r['agegroup'] || r['age'] || '';
                    const mark = row['Mark'] || row['Result'] || row['Time'] || r['mark'] || r['result'] || '';
                    const wind = row['Wind'] || r['wind'] || '';
                    const idr = row['IDR'] || row['idr'] || r['idr'] || '';
                    const dateRaw = row['Date'] || r['date'];
                    const country = row['Country'] || r['country'] || '';
                    const town = row['Town'] || row['City'] || r['town'] || '';
                    const raceName = row['Race Name'] || row['Meeting'] || r['racename'] || '';

                    if (!event || !mark) return; // Skip if no event or mark

                    // Date Parsing (Excel Date or String)
                    let finalDate = '';
                    if (dateRaw && !isNaN(dateRaw) && typeof dateRaw === 'number') {
                        // Excel serial date
                        const dateObj = new Date(Math.round((dateRaw - 25569) * 86400 * 1000));
                        finalDate = dateObj.toISOString().split('T')[0];
                    } else if (dateRaw) {
                        // Try string parse
                        const d = new Date(dateRaw);
                        if (!isNaN(d)) finalDate = d.toISOString().split('T')[0];
                        else finalDate = dateRaw; // Keep as string if needed
                    } else {
                        finalDate = new Date().toISOString().split('T')[0];
                    }

                    records.unshift({
                        id: Date.now() + Math.random(),
                        event: event.trim(),
                        athlete: finalAthleteName,
                        gender: gender.trim(),
                        ageGroup: ageGroup.toString().trim(),
                        mark: mark.toString().trim(),
                        wind: wind.toString().trim(),
                        idr: idr.toString().trim(),
                        date: finalDate,
                        country: country.trim(),
                        town: town.trim(),
                        raceName: raceName.trim(),
                        notes: (row['Note'] || row['note'] || r['note'] || row['Notes'] || r['notes'] || '').toString().trim()
                    });
                    importedCount++;
                });

                if (importedCount > 0) {
                    saveRecords();
                    saveAthletes();
                    saveCountries();

                    // Reset Filters to ensure visibility
                    if (filterEvent) filterEvent.value = 'all';
                    if (filterGender) filterGender.value = 'all';
                    if (filterAge) filterAge.value = 'all';
                    if (filterYear) filterYear.value = 'all';

                    populateYearDropdown();
                    renderReports();
                    renderEventList();
                    renderAthleteList();

                    alert(`Imported ${importedCount} records successfully.`);
                } else {
                    alert('No valid records found in file.');
                }

            } catch (err) {
                console.error(err);
                alert('Error processing file: ' + err.message);
            }
            // Reset input
            recordImportFile.value = '';
        };
        reader.readAsArrayBuffer(file);
    }

    function importDatabase() {
        const file = fileRestore.files[0];
        if (!file) return alert('Please select a JSON file first.');

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const db = JSON.parse(e.target.result);
                if (!Array.isArray(db.events) || !Array.isArray(db.records)) {
                    throw new Error('Invalid file format.');
                }
                const newAthletes = Array.isArray(db.athletes) ? db.athletes : [];

                if (!confirm(`Found ${db.records.length} records, ${newAthletes.length} athletes, and ${db.events.length} event types. Replace data?`)) {
                    return;
                }

                localStorage.setItem('tf_records', JSON.stringify(db.records));
                localStorage.setItem('tf_events', JSON.stringify(db.events));
                localStorage.setItem('tf_athletes', JSON.stringify(newAthletes));

                location.reload();
            } catch (err) {
                alert('Error parsing database file: ' + err.message);
            }
        };
        reader.readAsText(file);
    }


    // --- Stats Logic ---
    let statsSortField = 'count';
    let statsSortOrder = 'desc';

    window.sortStats = function (field) {
        if (statsSortField === field) {
            statsSortOrder = statsSortOrder === 'asc' ? 'desc' : 'asc';
        } else {
            statsSortField = field;
            statsSortOrder = field === 'count' ? 'desc' : 'asc';
        }
        renderStats();
    };

    // Expose renderStats globally for HTML attributes
    window.renderStats = renderStats;

    function renderStats() {
        if (!statsTableBody) return;
        statsTableBody.innerHTML = '';

        // Aggregate
        const agg = {};
        records.forEach(r => {
            // Exclude Relays
            const ev = events.find(e => e.name === r.event);
            const isRelay = ev ? (ev.isRelay || ev.name.includes('4x') || ev.name.includes('Σκυτάλη')) : (r.event && (r.event.includes('4x') || r.event.includes('Σκυτάλη')));

            if (isRelay) return;

            if (r.athlete) {
                if (!agg[r.athlete]) agg[r.athlete] = { count: 0, minYear: null, maxYear: null };
                agg[r.athlete].count++;
                if (r.date) {
                    const y = new Date(r.date).getFullYear();
                    const currentMin = agg[r.athlete].minYear;
                    const currentMax = agg[r.athlete].maxYear;
                    if (currentMin === null || y < currentMin) agg[r.athlete].minYear = y;
                    if (currentMax === null || y > currentMax) agg[r.athlete].maxYear = y;
                }
            }
        });

        // Populate Name Filter Dropdown
        const nameSelect = document.getElementById('statsFilterName');
        if (nameSelect && nameSelect.options.length <= 1) {
            const allNames = Object.keys(agg).sort();
            allNames.forEach(n => {
                const op = document.createElement('option');
                op.value = n;
                op.textContent = n;
                nameSelect.appendChild(op);
            });
        }

        // Populate Age Category Dropdown (Unique Categories from all data)
        const catSelect = document.getElementById('statsFilterCategory');
        if (catSelect && catSelect.options.length <= 1) {
            const categories = new Set();
            Object.keys(agg).forEach(name => {
                const athlete = athletes.find(a => `${a.lastName}, ${a.firstName}` === name);
                if (athlete && athlete.dob) {
                    const age = getExactAge(athlete.dob, new Date());
                    if (age !== null) {
                        let cat = '';
                        if (age < 35) cat = 'Senior';
                        else cat = (Math.floor(age / 5) * 5).toString(); // No Gender Prefix
                        categories.add(cat);
                    }
                }
            });
            // Sort: Senior first, then numeric
            Array.from(categories).sort((a, b) => {
                if (a === 'Senior') return -1;
                if (b === 'Senior') return 1;
                return parseInt(a) - parseInt(b);
            }).forEach(c => {
                const op = document.createElement('option');
                op.value = c;
                op.textContent = c;
                catSelect.appendChild(op);
            });
        }

        // Filter values (Read once)
        const genderFilterEl = document.getElementById('statsFilterGender');
        const nameFilterEl = document.getElementById('statsFilterName');
        const catFilterEl = document.getElementById('statsFilterCategory');
        const genderFilter = genderFilterEl ? genderFilterEl.value : 'all';
        const nameFilter = nameFilterEl ? nameFilterEl.value : 'all';
        const catFilter = catFilterEl ? catFilterEl.value : 'all';

        // console.log(`Stats Filter - Name: "${nameFilter}", Gender: "${genderFilter}"`);

        // Convert to Array & Enrich
        let statsData = Object.keys(agg).reduce((acc, name) => {
            const athlete = athletes.find(a => `${a.lastName}, ${a.firstName}` === name);

            // Name Filter (Exact) - If Name is selected, it overrides Gender filter
            if (nameFilter !== 'all') {
                if (name !== nameFilter) return acc;
            } else {
                // Gender Filter (Only check if Name not selected)
                if (genderFilter !== 'all') {
                    if (!athlete || athlete.gender !== genderFilter) return acc;
                }
            }

            const data = agg[name];
            let ratioVal = 0;
            if (data.minYear !== null && data.maxYear !== null && data.count > 0) {
                const diff = data.maxYear - data.minYear;
                if (diff > 0) {
                    // Formula: RecordCount / (MaxYear - MinYear)
                    ratioVal = (data.count / diff) * 100;
                }
            }

            const item = {
                name: name,
                count: data.count,
                ratio: ratioVal.toFixed(2) + '%',
                age: null,
                ageCategory: null,
                generalRank: null,
                ageRank: null,
                ageMedal: '',
                gender: athlete ? athlete.gender : ''
            };

            // Enrich with Age & Category
            if (athlete && athlete.dob) {
                const age = getExactAge(athlete.dob, new Date());
                item.age = age;
                if (age !== null) {
                    // Category Logic: <35 = 'Senior', >=35 = 5-year bucket
                    // Prefix: M or W based on gender
                    let prefix = (item.gender === 'Female') ? 'W' : 'M';

                    if (age < 35) item.ageCategory = 'Senior';
                    else item.ageCategory = prefix + (Math.floor(age / 5) * 5).toString();
                }
            }

            // Category Filter (Overrides if Name not selected)
            if (catFilter !== 'all' && nameFilter === 'all') {
                if (!item.ageCategory) return acc;
                let itemCat = item.ageCategory;
                if (itemCat !== 'Senior') itemCat = itemCat.replace(/^[MW]/, '');
                if (itemCat !== catFilter) return acc;
            }

            acc.push(item);
            return acc;
        }, []);

        if (statsData.length === 0) {
            statsTableBody.innerHTML = '<tr><td colspan="4" style="text-align:center;">No records found for selected filters.</td></tr>';
            return;
        }

        // --- Calculate Rankings ---


        // 2. General Rank
        // Sort temp array by count desc
        const sortedByCount = [...statsData].sort((a, b) => b.count - a.count);
        sortedByCount.forEach((item, index) => {
            item.generalRank = index + 1;
            if (item.generalRank === 1) item.generalRank += ' 🥇';
            else if (item.generalRank === 2) item.generalRank += ' 🥈';
            else if (item.generalRank === 3) item.generalRank += ' 🥉';
        });

        // 3. Age Category Rank
        // Group by category
        const contentByAge = {};
        statsData.forEach(item => {
            const cat = item.ageCategory || 'Unknown';
            if (!contentByAge[cat]) contentByAge[cat] = [];
            contentByAge[cat].push(item);
        });

        // Rank within groups
        Object.keys(contentByAge).forEach(cat => {
            const group = contentByAge[cat];
            group.sort((a, b) => b.count - a.count);
            group.forEach((item, index) => {
                item.ageRank = index + 1;
                if (item.ageRank === 1) item.ageMedal = '🥇';
                else if (item.ageRank === 2) item.ageMedal = '🥈';
                else if (item.ageRank === 3) item.ageMedal = '🥉';
            });
        });


        // --- Filter by Medal (Post-Ranking) ---
        const medalFilter = document.getElementById('statsFilterMedal') ? document.getElementById('statsFilterMedal').value : 'all';
        // Only apply Medal Filter if Name Filter is NOT active
        if (medalFilter !== 'all' && nameFilter === 'all') {
            statsData = statsData.filter(item => {
                if (medalFilter === 'gold') return item.ageMedal === '🥇';
                if (medalFilter === 'silver') return item.ageMedal === '🥈';
                if (medalFilter === 'bronze') return item.ageMedal === '🥉';
                if (medalFilter === 'any') return item.ageMedal !== '';
                return true;
            });
        }

        if (statsData.length === 0) {
            let msg = 'No athletes found with selected filters.';
            if (nameFilter !== 'all') msg += ` (Name: "${nameFilter}")`;
            statsTableBody.innerHTML = `<tr><td colspan="5" style="text-align:center;">${msg}</td></tr>`;
            return;
        }


        // --- User Display Sort ---
        statsData.sort((a, b) => {
            let valA = a[statsSortField];
            let valB = b[statsSortField];

            if (statsSortField === 'ratio') {
                valA = parseFloat(valA.replace('%', ''));
                valB = parseFloat(valB.replace('%', ''));
            } else if (statsSortField === 'generalRank' || statsSortField === 'ageRank') {
                // Clean strings (remove medals/whitespace) and parse int
                // If value is just number, parseInt works.
                // If "1 🥇", parseInt("1 🥇") -> 1.
                valA = parseInt(valA.toString());
                valB = parseInt(valB.toString());
            }

            // Case insensitive for names
            if (typeof valA === 'string') valA = valA.toLowerCase();
            if (typeof valB === 'string') valB = valB.toLowerCase();

            if (valA < valB) return statsSortOrder === 'asc' ? -1 : 1;
            if (valA > valB) return statsSortOrder === 'asc' ? 1 : -1;
            return 0;
        });

        // Render
        statsData.forEach((item, index) => {
            const uniqueId = `stats-detail-${index}`;

            // Age Badge (Existing Logic reused/adjusted)
            let ageDisplay = '';
            if (item.age !== null) {
                // Badge Style
                ageDisplay = `<span style="
                    background-color: var(--success);
                    color: white;
                    padding: 3px 10px;
                    border-radius: 12px;
                    font-size: 0.9em;
                    font-weight: 600;
                    margin-left: 10px;
                    margin-right: 15px;
                 ">Age: ${item.age}</span>`;
            }

            // Calculate Year Badges
            // 1. Get records for athlete
            // (Note: redundant filter here, optimize later if slow, strict validation says no redeclaring 'athleteRecords')
            const athleteRecords = records.filter(r => r.athlete === item.name);

            // 2. Group by Year
            const years = {};
            athleteRecords.forEach(r => {
                if (r.date) {
                    const y = new Date(r.date).getFullYear();
                    years[y] = (years[y] || 0) + 1;
                }
            });

            // 3. Sort Years Descending
            const sortedYears = Object.keys(years).sort((a, b) => b - a);

            // 4. Build HTML
            let yearBadgesHtml = '<div style="display:flex; gap:10px; flex-wrap:wrap; margin-left:5px;">';
            sortedYears.forEach(year => {
                yearBadgesHtml += `
                    <div style="
                        position: relative;
                        background-color: var(--primary); /* Blue */
                        border: none;
                        border-radius: 6px;
                        padding: 4px 10px;
                        font-size: 0.9em;
                        color: white;
                        margin-top: 6px;
                        font-weight: 500;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                    ">
                        ${year}
                        <div style="
                            position: absolute;
                            top: -10px;
                            right: -10px;
                            background-color: var(--danger); /* Red */
                            color: white;
                            border-radius: 50%;
                            width: 20px;
                            height: 20px;
                            font-size: 0.75em;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            font-weight: bold;
                            box-shadow: 0 1px 3px rgba(0,0,0,0.3);
                            border: 2px solid var(--bg-card); /* Border to separate from year box */
                        ">${years[year]}</div>
                    </div>
                `;
            });
            yearBadgesHtml += '</div>';

            // Age Rank Display
            let ageRankDisplay = '-';
            if (item.ageCategory) {
                ageRankDisplay = `<div style="display:flex; align-items:center; justify-content:flex-end;">
                    <span style="font-weight:bold; margin-right:5px;">${item.ageRank}</span>
                    <span style="font-size:2.5em; margin-right:5px;">${item.ageMedal}</span>
                    <span style="font-size:0.8em; opacity:0.6;">(${item.ageCategory})</span>
                </div>`;
            }

            // General Rank Display with large medal
            let genRankDisplay = item.generalRank;
            if (typeof item.generalRank === 'string' && item.generalRank.includes('🥇')) {
                genRankDisplay = item.generalRank.replace('🥇', '<span style="font-size:2.5em;">🥇</span>');
            } else if (typeof item.generalRank === 'string' && item.generalRank.includes('🥈')) {
                genRankDisplay = item.generalRank.replace('🥈', '<span style="font-size:2.5em;">🥈</span>');
            } else if (typeof item.generalRank === 'string' && item.generalRank.includes('🥉')) {
                genRankDisplay = item.generalRank.replace('🥉', '<span style="font-size:2.5em;">🥉</span>');
            }


            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td style="text-align:center; font-weight:bold; color:var(--text-muted);">${genRankDisplay}</td>
                <td style="font-weight:600; cursor:pointer; color:white;" onclick="toggleStatsDetail('${uniqueId}')">
                    <div style="display:flex; align-items:center;">
                        <span>${item.name} <span style="font-size:0.8em; opacity:0.7; margin-left:4px;">▼</span></span>
                        ${ageDisplay}
                    </div>
                    ${yearBadgesHtml}
                </td>
                <td style="text-align:right;">${item.ratio}</td>
                <td style="text-align:right;">${ageRankDisplay}</td>
                <td style="text-align:right; padding-right:15px;">${item.count}</td>
            `;
            statsTableBody.appendChild(tr);

            // Detail Row
            const trDetail = document.createElement('tr');
            trDetail.id = uniqueId;
            trDetail.className = 'hidden';
            // Light blue background for details (using accent color with low opacity)
            trDetail.style.backgroundColor = 'rgba(6, 182, 212, 0.1)';

            // Get records for this athlete (Already fetched above in athleteRecords)
            // Sort by date desc
            athleteRecords.sort((a, b) => new Date(b.date) - new Date(a.date));

            let detailsHtml = `
                <div style="padding: 10px; margin-left: 20px;">
                    <table style="width:100%; font-size: 0.9em; border-collapse: collapse;">
                        <thead style="background: rgba(6, 182, 212, 0.2);">
                            <tr>
                                <th style="padding:4px; text-align:left;">Event</th>
                                <th style="padding:4px; text-align:left;">Age</th>
                                <th style="padding:4px; text-align:left;">Mark</th>
                                <th style="padding:4px; text-align:left;">Date</th>
                                <th style="padding:4px; text-align:left;">Race</th>
                                <th style="padding:4px; text-align:left;">Place</th>
                            </tr>
                        </thead>
                        <tbody>
            `;

            athleteRecords.forEach(r => {
                detailsHtml += `
                    <tr>
                        <td style="padding:4px; border-bottom:1px solid rgba(255,255,255,0.1);">${r.event}</td>
                        <td style="padding:4px; border-bottom:1px solid rgba(255,255,255,0.1);">${r.ageGroup || '-'}</td>
                        <td style="padding:4px; border-bottom:1px solid rgba(255,255,255,0.1);"><b>${r.mark}</b></td>
                        <td style="padding:4px; border-bottom:1px solid rgba(255,255,255,0.1);">${r.date}</td>
                        <td style="padding:4px; border-bottom:1px solid rgba(255,255,255,0.1);">${r.raceName || '-'}</td>
                        <td style="padding:4px; border-bottom:1px solid rgba(255,255,255,0.1);">${r.town || r.location || '-'}</td>
                    </tr>
                `;
            });

            detailsHtml += `
                        </tbody>
                    </table>
                </div>
            `;

            trDetail.innerHTML = `
                <td colspan="2" style="padding:0;">${detailsHtml}</td>
            `;
            statsTableBody.appendChild(trDetail);
        });
    }

    window.toggleStatsDetail = function (id) {
        const el = document.getElementById(id);
        if (el) el.classList.toggle('hidden');
    };

    // Fallback if needed
    window.addEventListener('load', () => {
        setTimeout(populateYearDropdown, 500);
    });

    // --- IAAF Scoring Tables Logic ---

    async function loadIAAFData() {
        if (isIAAFDataLoaded) {
            renderIAAFFilters();
            return;
        }

        const loadingIndicator = document.getElementById('iaafLoading');
        const container = document.getElementById('iaafTableContainer');
        // const emptyState = document.querySelector('#setting-iaaf .empty-state'); 

        if (loadingIndicator) loadingIndicator.classList.remove('hidden');
        if (container) container.classList.add('hidden');

        // Check if data is already global (from previous load or pre-load)
        if (window.IAAF_SCORING_DATA) {
            iaafData = window.IAAF_SCORING_DATA;
            isIAAFDataLoaded = true;
            renderIAAFFilters();
            if (loadingIndicator) loadingIndicator.classList.add('hidden');
            if (container) container.classList.remove('hidden');
            return;
        }

        // Dynamic Script Injection (Bypasses CORS on local file://)
        const script = document.createElement('script');
        script.src = 'data/iaaf_data.js';

        script.onload = () => {
            if (window.IAAF_SCORING_DATA) {
                iaafData = window.IAAF_SCORING_DATA;
                isIAAFDataLoaded = true;
                renderIAAFFilters();
            } else {
                alert('Error: Data loaded but variable not found.');
            }
            if (loadingIndicator) loadingIndicator.classList.add('hidden');
            if (container) container.classList.remove('hidden');
        };

        script.onerror = (e) => {
            console.error('Script load error:', e);
            // Fallback or error message
            // Maybe try fetch as backup if script fails? Unlikely if file missing.
            alert('Failed to load IAAF Scoring Tables (data/iaaf_data.js). Please ensure the file exists.');
            if (loadingIndicator) loadingIndicator.classList.add('hidden');
        };

        document.body.appendChild(script);
    }

    // Assign to window for HTML access (or keep local if only called from JS)
    // Actually, onchange="renderIAAFFilters()" in HTML needs it to be global OR attached to window.
    // If inside closure, HTML can't see it unless we explicitly attach to window.
    window.renderIAAFFilters = function () {
        if (!isIAAFDataLoaded) return;

        const gender = document.getElementById('iaafFilterGender').value; // men, women
        const eventSelect = document.getElementById('iaafFilterEvent');

        const availableEvents = [...new Set(iaafData
            .filter(d => d.gender === gender)
            .map(d => d.event)
        )].sort();

        // Save current selection if still valid
        const currentEvent = eventSelect.value;
        eventSelect.innerHTML = '<option value="" disabled selected>Select Event...</option>';

        availableEvents.forEach(evt => {
            const option = document.createElement('option');
            option.value = evt;
            option.textContent = evt;
            eventSelect.appendChild(option);
        });

        if (availableEvents.includes(currentEvent)) {
            eventSelect.value = currentEvent;
        } else {
            document.getElementById('iaafTableBody').innerHTML = '';
        }

        renderIAAFTable();
    };

    window.renderIAAFTable = function () {
        // const category = document.getElementById('iaafFilterCategory').value;
        const gender = document.getElementById('iaafFilterGender').value;
        const eventName = document.getElementById('iaafFilterEvent').value;
        const tbody = document.getElementById('iaafTableBody');
        tbody.innerHTML = '';

        if (!eventName) return;

        const records = iaafData
            .filter(d => d.gender === gender && d.event === eventName)
            .sort((a, b) => b.points - a.points); // Sort by points high to low

        const fragment = document.createDocumentFragment();

        records.forEach(r => {
            let mark = r.mark;
            let points = r.points;

            if (iaafUpdates[r.id]) {
                mark = iaafUpdates[r.id].mark !== undefined ? iaafUpdates[r.id].mark : mark;
                points = iaafUpdates[r.id].points !== undefined ? iaafUpdates[r.id].points : points;
            }

            if (iaafUpdates[r.id] && iaafUpdates[r.id].deleted) return; // Skip deleted rows

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td id="mark-${r.id}" contenteditable="true" onblur="handleIAAFEdit(${r.id}, 'mark', this.innerText)">${mark}</td>
                <td contenteditable="true" onblur="handleIAAFEdit(${r.id}, 'points', this.innerText)">${points}</td>
                <td style="text-align:center;">
                    <button class="btn-icon edit" onclick="window.enableIAAFEdit(${r.id})" title="Edit">✏️</button>
                    <button class="btn-icon delete" onclick="window.deleteIAAFRow(${r.id})" title="Delete Row">🗑️</button>
                    ${iaafUpdates[r.id] && !iaafUpdates[r.id].deleted ? `<button class="btn-icon" onclick="window.revertIAAFEdit(${r.id})" title="Revert Changes" style="color:var(--text-muted);">↺</button>` : ''}
                </td>
            `;
            fragment.appendChild(tr);
        });

        tbody.appendChild(fragment);
    };

    window.handleIAAFEdit = function (id, field, value) {
        if (!iaafUpdates[id]) iaafUpdates[id] = {};
        iaafUpdates[id][field] = value;
        saveIAAFUpdates();
        // Don't re-render entire table to keep focus
        // Maybe show Revert button? 
        // We can find the row and update the actions cell?
        // For now, simplicity: Revert button appears on next render or refresh. 
        // Or we can manually append it.
        const btn = document.querySelector(`button[onclick="window.revertIAAFEdit(${id})"]`);
        if (!btn) {
            // force re-render or just let user refresh?
            // Since "Actions" column is updated, we SHOULD re-render row actions.
            // But simpler to just let it save.
            renderIAAFTable();
        }
    };

    window.enableIAAFEdit = function (id) {
        const cell = document.getElementById(`mark-${id}`);
        if (cell) {
            cell.focus();
            // Highlight row?
            cell.parentElement.style.background = 'rgba(139, 92, 246, 0.1)';
            setTimeout(() => cell.parentElement.style.background = '', 1000);
        }
    };

    window.deleteIAAFRow = function (id) {
        if (confirm('Are you sure you want to delete this row?')) {
            if (!iaafUpdates[id]) iaafUpdates[id] = {};
            iaafUpdates[id].deleted = true;
            saveIAAFUpdates();
            renderIAAFTable();
        }
    };

    window.revertIAAFEdit = function (id) {
        if (confirm('Revert this record to original values?')) {
            delete iaafUpdates[id];
            saveIAAFUpdates();
            renderIAAFTable();
        }
    };

});


function saveIAAFUpdates() {
    localStorage.setItem('tf_iaaf_updates', JSON.stringify(iaafUpdates));
}

// Connect to Tab System
// We need to trigger loadIAAFData when the tab is shown.
// The tab system uses data-subtab="iaaf".
// I need to find where tabs are switched.
